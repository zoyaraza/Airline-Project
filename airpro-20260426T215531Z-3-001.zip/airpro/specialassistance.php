<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Special Assistance - FAST Airways</title>
    <style>
        /* Custom button color */
        .btn-custom {
            background-color: #942454;
            color: white;
        }

        .btn-custom:hover {
            background-color: #7a1e42;
        }
    </style>
</head>

<body>
    <?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2>Request Special Assistance</h2>
        <p>At FAST Airways, we strive to ensure every passenger has a comfortable journey. Request special assistance by
            filling in your passenger ID and selecting the type of assistance required.</p>

        <!-- Display Messages -->
        <?php if (isset($_GET['message'])): ?>
        <?php
            $message = "";
            $alert_class = "";
            switch ($_GET['message']) {
                case 'success':
                    $alert_class = 'alert-success';
                    $message = "Special assistance requested successfully!";
                    break;
                case 'error':
                    $alert_class = 'alert-danger';
                    $message = "Error saving request. Please try again.";
                    break;
                case 'notfound':
                    $alert_class = 'alert-warning';
                    $message = "Passenger ID not found. Please check and try again.";
                    break;
                case 'missingfields':
                    $alert_class = 'alert-warning';
                    $message = "All fields are required. Please fill in the form completely.";
                    break;
                default:
                    $alert_class = 'alert-info';
                    $message = "Unexpected status.";
            }
        ?>
        <div class="alert <?php echo $alert_class; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <!-- Special Assistance Form -->
        <form action="partials/_submit_assistance.php" method="POST">
            <div class="form-group">
                <label for="passenger_id">Enter Your Passenger ID:</label>
                <input type="text" class="form-control" id="passenger_id" name="passenger_id" required
                    placeholder="Passenger ID">
            </div>

            <div class="form-group">
                <label for="assistance_type">Select Type of Assistance:</label>
                <select class="form-control" id="assistance_type" name="assistance_type" required>
                    <option value="">Choose Assistance</option>
                    <option value="Wheelchair">Wheelchair Assistance</option>
                    <option value="Boarding">Help with Boarding/Deplaning</option>
                    <option value="Visual">Support for Visual Impairments</option>
                    <option value="Hearing">Support for Hearing Impairments</option>
                    <option value="Special Seating">Special Seating Arrangements</option>
                </select>
            </div>

            <button type="submit" class="btn btn-custom">Request Assistance</button>
        </form>

        <a href="index.php" class="btn btn-custom mt-3">Back to Home</a>
    </div>

    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Automatically hide the alert message after 3 seconds
        setTimeout(() => {
            const alertElement = document.querySelector('.alert-dismissible');
            if (alertElement) {
                alertElement.classList.remove('show');
                alertElement.style.display = 'none';
            }
        }, 3000);
    </script>
</body>

</html>
