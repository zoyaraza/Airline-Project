<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if all fields are filled
    if (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['feedback'])) {
        // Redirect with error message if any field is empty
        header('Location: feedback_form.php?error=1');
        exit;
    }

    // Here, you can add your code to save the feedback to a database, send it by email, etc.
    // For this example, we assume feedback is successfully processed.

    // Redirect with success message
    header('Location: feedback_form.php?success=1');
    exit;
}
?>
