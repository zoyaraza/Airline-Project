<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaints - FAST Airways</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .section-title {
            font-size: 1.8rem;
            margin-bottom: 20px;
            text-align: center;
        }

        .section-subtitle {
            text-align: center;
            margin-bottom: 40px;
        }

        .card-deck {
            display: flex;
            justify-content: space-around;
        }

        .card {
            width: 30%;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        /* Changed hover effect for the card */
        .card:hover {
            transform: scale(1.05);
            background-color: #f0f0f0; /* Lighter gray shade on hover */
        }

        /* Updated icon color */
        .card-icon {
            font-size: 3rem;
            color: #7a1e42; /* Set to match button color */
            margin-top: 20px;
        }

        .card-title {
            font-weight: bold;
            margin-top: 15px;
        }

        .card-text {
            font-size: 1rem;
            margin-bottom: 20px;
        }

        /* Custom button color */
        .btn-custom {
            background-color: #942454; /* Changed to your specified color */
            color: white;
            font-weight: bold;
            border-radius: 5px;
            padding: 10px 20px;
            text-decoration: none;
        }

        /* Changed hover effect for the button */
        .btn-custom:hover {
            background-color: #7a1e42; /* Darker shade for button hover */
            color: black; /* Text color changes to black on hover */
        }
    </style>
</head>

<body>
<?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2 class="section-title">Leave Your Feedback</h2>
        <p class="section-subtitle">Your opinion is important to us. Help us improve your online experience.</p>

        <!-- Card Deck -->
        <div class="card-deck">
            <!-- Leave Website Feedback Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <h5 class="card-title">Leave Website Feedback</h5>
                    <p class="card-text">Your opinion is important to us. Help us improve your online experience.</p>
                    <a href="feedback_form.php" class="btn-custom">Submit Feedback</a>
                </div>
            </div>

            <!-- Get in Touch Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h5 class="card-title">Get in Touch</h5>
                    <p class="card-text">Need answers? Here are the most convenient ways to contact us.</p>
                    <a href="_contact.php" class="btn-custom">Contact Us</a>
                </div>
            </div>

            <!-- Raise a Concern Card -->
            <div class="card">
                <div class="card-body">
                    <div class="card-icon">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <h5 class="card-title">Raise a Concern</h5>
                    <p class="card-text">If you’ve had a less than satisfying experience, we’d like to hear from you.</p>
                    <a href="complaint_form.php" class="btn-custom">Submit a Complaint</a>
                </div>
            </div>
        </div>
    </div>
    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
