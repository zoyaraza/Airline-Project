<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Pre-book Meals - FAST Airways</title>
    <style>
        .meal-img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        /* Custom button color */
        .btn-custom {
            background-color: #942454;
            color: white;
        }
    </style>
</head>

<body>
    <?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2>Pre-book Meals</h2>

        <!-- Display Messages -->
        <?php if (isset($_GET['message'])): ?>
            <div class="alert 
                <?php
                switch ($_GET['message']) {
                    case 'success':
                        echo 'alert-success';
                        $message = "Meal pre-booked successfully!";
                        break;
                    case 'error':
                        echo 'alert-danger';
                        $message = "Error updating meal preference. Please try again.";
                        break;
                    case 'notfound':
                        echo 'alert-warning';
                        $message = "Passenger ID not found. Please check and try again.";
                        break;
                    case 'missingfields':
                        echo 'alert-warning';
                        $message = "All fields are required. Please fill in the form completely.";
                        break;
                    default:
                        echo 'alert-info';
                        $message = "Unexpected status.";
                }
                ?>
            " role="alert">
                <?php echo $message; ?>
            </div>
            <script>
                // Hide alert after 3 seconds
                setTimeout(function () {
                    document.querySelector('.alert').style.display = 'none';
                }, 3000);
            </script>
        <?php endif; ?>

        <p>The default meal for every passenger is <strong>Chicken Meal</strong>. If you wish to choose a different meal, please select one of the options below. The selected meal will replace the default.</p>
        <p>Here are some of the meal options you can pre-book:</p>

        <!-- Meal Selection Form -->
        <form action="partials/_submit_meal.php" method="POST">
            <div class="row">
                <!-- Vegetarian Meal -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://www.gigadocs.com/blog/wp-content/uploads/2020/03/istock-955998758.jpg" class="card-img-top meal-img" alt="Vegetarian Meal">
                        <div class="card-body">
                            <h5 class="card-title">Vegetarian Meal</h5>
                            <p class="card-text">A wholesome meal with a variety of fresh vegetables and grains.</p>
                            <input type="radio" name="meal" value="Vegetarian" id="vegetarian" required>
                            <label for="vegetarian">Choose Vegetarian Meal</label>
                        </div>
                    </div>
                </div>

                <!-- Vegan Meal -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://images.immediate.co.uk/production/volatile/sites/30/2023/01/Ponzu-tofu-poke-bowl-8733c67.jpg?quality=90&webp=true&resize=300,272" class="card-img-top meal-img" alt="Vegan Meal">
                        <div class="card-body">
                            <h5 class="card-title">Vegan Meal</h5>
                            <p class="card-text">A delicious plant-based meal with nutrient-rich ingredients.</p>
                            <input type="radio" name="meal" value="Vegan" id="vegan" required>
                            <label for="vegan">Choose Vegan Meal</label>
                        </div>
                    </div>
                </div>

                <!-- Gluten-Free Meal -->
                <div class="col-md-4">
                    <div class="card">
                        <img src="https://images.immediate.co.uk/production/volatile/sites/30/2013/05/BBC_GF0521_25.3.21_Shivi_GilledNectarineBurrataSalad-053-copy-108f98a.jpg?quality=90&webp=true&resize=300,272" class="card-img-top meal-img" alt="Gluten-Free Meal">
                        <div class="card-body">
                            <h5 class="card-title">Gluten-Free Meal</h5>
                            <p class="card-text">A delicious meal without gluten, perfect for sensitive diets.</p>
                            <input type="radio" name="meal" value="Gluten-Free" id="glutenFree" required>
                            <label for="glutenFree">Choose Gluten-Free Meal</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Additional Meal Options -->
            <div class="mt-4">
                <label for="passenger_id">Enter Your Passenger ID for Pre-booking:</label>
                <input type="text" class="form-control" id="passenger_id" name="passenger_id" required placeholder="Passenger ID">
            </div>

            <button type="submit" class="btn btn-custom mt-3">Pre-book Meal</button>
        </form>

        <a href="index.php" class="btn btn-custom mt-3">Back to Home</a>
    </div>

    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
