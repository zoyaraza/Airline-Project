<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Complaint Form - FAST Airways</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #942454;
        }

        .btn-primary {
            background-color: #942454;
            border-color: #942454;
        }

        .btn-primary:hover {
            background-color: #701a3f;
            border-color: #701a3f;
        }
    </style>
</head>

<body>
    <?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2>Complaint Form</h2>
        
        <?php
        // Check if the user is logged in
        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
            echo '<div class="alert alert-warning">Please log in or sign up to submit a complaint.</div>';
            echo '<div class="mt-3">';
            echo '<button class="btn btn-primary" data-toggle="modal" data-target="#LoginModel">Login</button>';
            echo '<button class="btn btn-secondary ml-2" data-toggle="modal" data-target="#signupModel">Sign Up</button>';
            echo '</div>';
            echo '<div class="mt-2">';
            echo '<a href="index.php" class="btn btn-light">Back to Home</a>';
            echo '</div>';
        } else {
            // Retrieve user_id from session
            $user_id = $_SESSION['user_id'];
            include 'partials/_dbconnect.php';

            // Check if the user has already submitted a complaint
            $query = "SELECT complaints, complaint_status FROM user WHERE user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($complaints, $complaint_status);
            $stmt->fetch();
            $stmt->close();

            if ($complaints) {
                // User has already made a complaint
                echo '<div class="alert alert-info">You have already submitted a complaint.</div>';
                echo '<p><strong>Complaint:</strong> ' . htmlspecialchars($complaints) . '</p>';
                echo '<p><strong>Status:</strong> ' . htmlspecialchars($complaint_status) . '</p>';
                echo '<a href="index.php" class="btn btn-primary">Go Back</a>';
            } else {
                // Show the complaint form if no complaint exists
                echo '<p>We value your feedback and are here to assist with any issues you may have experienced during your flight. Please submit your complaint below.</p>';
        ?>

        <form action="partials/_submit_complaint.php" method="post">
            <div class="form-group">
                <label for="complaints">Your Complaint</label>
                <textarea class="form-control" id="complaints" name="complaints" rows="5" placeholder="Describe the issue you experienced" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Complaint</button>
            <a href="index.php" class="btn btn-secondary">Go Back</a>
        </form>

        <?php 
            } // End of else
        } // End of login check
        ?>

        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success mt-3">Your complaint has been submitted successfully.</div>
        <?php elseif (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <div class="alert alert-danger mt-3">There was an error submitting your complaint. Please try again.</div>
        <?php endif; ?>

    </div>

    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
