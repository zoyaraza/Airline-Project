<?php
// Include the database connection
include 'partials/_dbconnect.php';

// Fetch cities from the database
$sql = "SELECT city_id, name FROM city";
$result = mysqli_query($conn, $sql);
$cities = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $cities[] = $row;
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
       .card-title {
        font-size: 1.2em;
        font-weight: bold;
        color: #902454;
        text-align: center;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .card img {
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        height: 150px;
        object-fit: cover;
    }

    .btn-primary {
    background-color: #942454;
    border-color: #942454;
}

.btn-primary:hover {
    background-color: #5a3e45;
    border-color: #5a3e45;
}
    </style>
</head>

<body>
    <?php include 'partials/_dbconnect.php'; ?>
   <?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include 'partials/_headeradmin.php';
} else {
    // Include the default header if the user is not an admin
    include 'partials/_header.php';
}?>
    <!-- Slider starts here -->
    <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://images.unsplash.com/photo-1541674162775-15fd6b6802e3?q=80&w=1488&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                    class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Can't Decide Where To Go?</h5>
                    <p>Explore Every Destination With FAST Airways</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1483450388369-9ed95738483c?q=80&w=1488&h=580&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                    class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Explore the World with FAST Airways</h5>
                    <p>Experience New Adventures and Make Memories.</p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

<!-- Flight Booking Section -->
<div class="container my-5">
    <h2 class="text-center">Book a Flight</h2>
    <div class="flight-booking-form border p-4 rounded shadow-sm" style="border: 2px solid #902454; outline: 5px solid #902454;">
        <form action="partials/flightslist2.php" method="GET">
            <div class="form-row align-items-center">
                <div class="col-auto">
                    <label for="tripType">Trip Type</label><br>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="tripType" id="return" value="return" checked>
                        <label class="form-check-label" for="return">Return</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="tripType" id="oneway" value="oneway">
                        <label class="form-check-label" for="oneway">One Way</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="tripType" id="multicity" value="multicity">
                        <label class="form-check-label" for="multicity">Multi-City</label>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="from">From</label>
                    <select id="from" name="from" class="form-control" required>
                        <option value="" selected disabled>Select a City</option>
                        <?php foreach ($cities as $city): ?>
                            <option value="<?= $city['city_id'] ?>"><?= $city['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="to">To</label>
                    <select id="to" name="to" class="form-control" required>
                        <option value="" selected disabled>Select a City</option>
                        <?php foreach ($cities as $city): ?>
                            <option value="<?= $city['city_id'] ?>"><?= $city['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="departure">Departure</label>
                    <input type="date" class="form-control" id="departure" name="departure" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="return">Return</label>
                    <input type="date" class="form-control" id="return" name="return">
                </div>
            </div>

            <!-- Search Flights Button Row -->
            <div class="form-row">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary" style="border-radius: 50px; font-size: 16px; padding: 10px 30px; background-color: #902454; border-color: #902454;">
                        Search Flights
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>


</body>
</html>

  <!-- Service Boxes Section -->
<div class="container my-5">
    <h2 class="text-left">Help</h2>
    <div class="row text-center g-4"> <!-- Added g-4 for consistent gaps -->
        <!-- Service Boxes (Pre-book Meals, Special Assistance, Complaints, Policies) -->
        <div class="col-md-3 my-4">
            <a href="#" data-toggle="modal" data-target="#preBookMealsModal" class="text-decoration-none">
                <div class="card p-3 shadow-sm h-100 d-flex flex-column">
                    <img src="https://ichef.bbci.co.uk/food/ic/food_16x9_832/recipes/spicy_salmon_bite_rice_16300_16x9.jpg" alt="Pre-book Meals" class="card-img-top">
                    <h5 class="card-title">Pre-book Meals</h5>
                </div>
            </a>
        </div>

        <div class="col-md-3 my-4">
            <a href="#" data-toggle="modal" data-target="#specialAssistanceModal" class="text-decoration-none">
                <div class="card p-3 shadow-sm h-100 d-flex flex-column">
                    <img src="https://wheelchairtravel.org/content/images/wp-content/uploads/2020/01/faq-air-special-assistance-v2020-header-scaled.jpg" alt="Special Assistance" class="card-img-top">
                    <h5 class="card-title">Special Assistance</h5>
                </div>
            </a>
        </div>

        <div class="col-md-3 my-4">
            <a href="#" data-toggle="modal" data-target="#complaintsModal" class="text-decoration-none">
                <div class="card p-3 shadow-sm h-100 d-flex flex-column">
                    <img src="https://lirp.cdn-website.com/c0515572c8574e74833387110f1929ab/dms3rep/multi/opt/328a3088-d204-41be-b588-73a74ce6af83-1920w.jpg" alt="Complaints" class="card-img-top">
                    <h5 class="card-title">Complaints/Feedback</h5>
                </div>
            </a>
        </div>

        <div class="col-md-3 my-4">
            <a href="#" data-toggle="modal" data-target="#policiesModal" class="text-decoration-none">
                <div class="card p-3 shadow-sm h-100 d-flex flex-column">
                    <img src="https://www.simplilearn.com/ice9/free_resources_article_thumb/project-documentation-article.jpg" alt="Policies" class="card-img-top">
                    <h5 class="card-title">Policies</h5>
                </div>
            </a>
        </div>
    </div>
</div>



      <!-- Modals Section -->
 <!-- Pre-book Meals Modal -->
<div class="modal fade" id="preBookMealsModal" tabindex="-1" aria-labelledby="preBookMealsLabel" aria-hidden="true">
    
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header ">
                <h5 class="modal-title" id="preBookMealsLabel">Pre-book Meals</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <p>Choose from a variety of delicious meal options to enjoy during your flight.</p>
            </div>
            <div class="modal-footer">
                <a href="prebookmeals.php" class="btn btn-primary">Learn More</a>
            </div>
        </div>
    </div>
</div>


    <!-- Special Assistance Modal -->
    <div class="modal fade" id="specialAssistanceModal" tabindex="-1" aria-labelledby="specialAssistanceLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="specialAssistanceLabel">Special Assistance</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    We offer personalized assistance for passengers with special needs.
                </div>
                <div class="modal-footer">
                    <a href="specialassistance.php" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Complaints Modal -->
    <div class="modal fade" id="complaintsModal" tabindex="-1" aria-labelledby="complaintsLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="complaintsLabel">Complaints</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    If you have any complaints or issues, please contact us.
                </div>
                <div class="modal-footer">
                    <a href="complaints.php" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Policies Modal -->
    <div class="modal fade" id="policiesModal" tabindex="-1" aria-labelledby="policiesLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="policiesLabel">Policies</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Please read through our company policies for a smooth experience.
                </div>
                <div class="modal-footer">
                    <a href="policies.php" class="btn btn-primary">Learn More</a>
                </div>
            </div>
        </div>
    </div>

    <?php include 'partials/_footer.php'; ?>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>

</html>








