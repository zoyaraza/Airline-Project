<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Book Flights - FAST Airways</title>

    <style>
      .img-rect {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 10px; /* Add rounded corners */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Add shadow for depth */
        transition: transform 0.3s ease-in-out; /* Smooth hover effect */
      }
      .img-rect:hover {
        transform: scale(1.05); /* Slight zoom on hover */
      }
      .img-container {
        width: 100%;
        height: 400px; /* Increased height for larger images */
        overflow: hidden;
        margin-top: 20px; /* Add spacing above images */
      }
    </style>
  </head>
  <body>
  <?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include 'partials/_headeradmin.php';
} else {
    // Include the default header if the user is not an admin
    include 'partials/_header.php';
}?>
     <!-- About Section -->
     <div class="container my-5">
       <h1 class="text-center">About FAST Airways</h1>

       <!-- History Section -->
       <div class="row mt-4">
         <div class="col-md-6">
           <h2>Our History</h2>
           <p>FAST Airways was founded in 1990 with the vision of providing affordable and comfortable air travel to passengers worldwide. Over the years, the airline has expanded its operations to multiple countries, built a fleet of state-of-the-art aircraft, and earned a reputation for safety, reliability, and customer service.</p>
           <div class="img-container">
             <img src="https://www.saudia.com/pages/-/media/Project/SA/SC/SV_Content/images/1.jpg?rev=28a6d4f1c4924388a93c25f916a16455&hash=90404422F0BC973AC2BCCA945E67555C" alt="FAST Airways History" class="img-rect">
           </div>
         </div>

         <!-- Vision Section -->
         <div class="col-md-6">
           <h2>Our Vision</h2>
           <p>At FAST Airways, our vision is to become the most trusted and innovative airline, offering exceptional travel experiences and leading the industry in sustainability. We aim to connect people and places, fostering economic growth and cultural exchange through a safe, reliable, and customer-focused approach.</p>
           <div class="img-container">
             <img src="https://www.ciasl.aero/ckeditor/upload/vision-img.jpg" alt="FAST Airways Vision" class="img-rect">
           </div>
         </div>
       </div>
     </div>

     <?php include 'partials/_footer.php';?>

    <!-- Optional JavaScript; choose one of the two! -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html>
