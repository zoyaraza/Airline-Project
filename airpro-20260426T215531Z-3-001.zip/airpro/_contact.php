<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Contact Us - FAST Airways</title>
    <style>
        body {
            background-color: #f8f9fa; /* Light gray background for the page */
        }

        .container {
            background-color: #ffffff; /* White background for the form and info section */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1, h3, h4 {
            color: #942454; /* Custom color for headers */
        }

        .btn-primary {
            background-color: #942454; /* Custom button color */
            border-color: #7a1e42; /* Darker shade for button border */
        }

        .btn-primary:hover {
            background-color: #7a1e42; /* Darker shade for button hover */
            border-color: #5e1537;
        }

        .form-control {
            border-radius: 5px;
            border: 1px solid #ddd; /* Light border color */
        }

        .form-group label {
            color: #333; /* Dark gray color for labels */
        }

        .contact-info p, .contact-info a {
            color: #333; /* Dark gray color for contact info text */
        }

        .contact-info a:hover {
            color: #942454; /* Custom color on hover for links */
        }

        .row {
            margin-top: 30px;
        }

        iframe {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
  </head>
  <body>
  <?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include 'partials/_headeradmin.php';
} else {
    // Include the default header if the user is not an admin
    include 'partials/_header.php';
}?>
    <div class="container mt-5">
      <h1 class="text-center mb-4">Contact Us</h1>

      <div class="row">
        <!-- Contact Form -->
        <div class="col-md-8">
          <h3>Send us a Message</h3>
          <form action="submit_form.php" method="POST">
            <div class="form-group">
              <label for="name">Full Name</label>
              <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
              <label for="email">Email Address</label>
              <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
              <label for="message">Message</label>
              <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>

        <!-- Contact Info -->
        <div class="col-md-4 contact-info">
          <h3>Our Office</h3>
          <p><strong>FAST Airways</strong><br>1234 Aviation Blvd,<br>Sky City, SC 12345</p>

          <h4>Phone:</h4>
          <p>+1 (800) 123-4567</p>

          <h4>Email:</h4>
          <p><a href="mailto:support@fastairways.com">airlineproject18@gmail.com</a></p>
        </div>
      </div>

      <!-- Map Section -->
      <div class="row mt-5">
        <div class="col-12">
          <h3>Our Location</h3>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.051631765617!2d144.955894015221!3d-37.81719977975119!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d8d8b52b84b%3A0x5045675218ce7e0!2sGoogle!5e0!3m2!1sen!2sus!4v1630916240527!5m2!1sen!2sus" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
      </div>
    </div>

    <?php include 'partials/_footer.php'; ?>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  </body>
</html>
