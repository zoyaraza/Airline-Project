<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Policies - FAST Airways</title>
    <style>
        body {
            background-color: #f4f6f9; /* Light background color */
        }

        .container {
            background-color: #ffffff; /* White content background */
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #942454; /* Blue color for titles */
            margin-bottom: 20px;
        }

        h4 {
            color: #942454; /* Matching blue for headings */
            margin-top: 20px;
        }

        p {
            color: #333; /* Dark gray text */
            font-size: 16px;
        }

        .btn-primary {
            background-color: #942454; /* New button color */
            border-color: #942454;
        }

        .btn-primary:hover {
            background-color: #701a3f; /* Darker shade for hover */
            border-color: #701a3f;
        }

        .btn-secondary {
            background-color: #6c757d; /* Gray button */
            border-color: #5a6268;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #4e555b;
        }
    </style>
</head>

<body>
    <?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2>Policies</h2>
        <p>At FAST Airways, we believe in transparency and clarity. Below are our important travel and safety policies that you should be aware of before flying with us:</p>

        <h4>1. Cancellation and Refund Policy</h4>
        <p>If you need to cancel your flight, please refer to our cancellation policy on the booking page for detailed instructions on how to request a refund.</p>
        
        <h4>2. Baggage Policy</h4>
        <p>Each passenger is allowed to check in a certain amount of baggage, and additional charges apply for excess baggage. Please visit the baggage policy page for more details.</p>
        
        <h4>3. Safety and Security</h4>
        <p>Your safety is our top priority. We follow all global safety standards and regulations to ensure a secure flight experience.</p>

        <h4>4. Passenger Rights</h4>
        <p>We respect your rights as a passenger and follow all consumer protection regulations for air travel. Read more about your rights here.</p>

        <a href="index.php" class="btn btn-primary">Back to Home</a>
    </div>

    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
