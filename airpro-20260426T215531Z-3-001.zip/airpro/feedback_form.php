<?php
session_start(); // Ensure the session is started
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #942454;
        }

        .btn-primary {
            background-color: #942454;
            border-color: #942454;
        }

        .btn-primary:hover {
            background-color: #701a3f;
            border-color: #701a3f;
        }
    </style>
</head>

<body>
    <?php include 'partials/_header.php'; ?>

    <div class="container my-5">
        <h2>Feedback Form</h2>

        <?php
        include 'partials/_dbconnect.php';

        // Check if the user is logged in
        if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
            echo '<div class="alert alert-warning">Please log in or sign up to submit feedback.</div>';
            echo '<div class="mt-3">';
            echo '<button class="btn btn-primary" data-toggle="modal" data-target="#LoginModel">Login</button>';
            echo '<button class="btn btn-secondary ml-2" data-toggle="modal" data-target="#signupModel">Sign Up</button>';
            echo '</div>';
            echo '<div class="mt-2">';
            echo '<a href="index.php" class="btn btn-light">Back to Home</a>';
            echo '</div>';
        } else {
            // Retrieve user_id from session
            $user_id = $_SESSION['user_id'];

            // Check if the user has already submitted feedback
            $query = "SELECT feedback FROM user WHERE user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($feedback);
            $stmt->fetch();
            $stmt->close();

            if ($feedback) {
                // Feedback already exists
                echo '<div class="alert alert-info">You have already submitted feedback.</div>';
                echo '<p><strong>Feedback:</strong> ' . htmlspecialchars($feedback) . '</p>';
                echo '<a href="index.php" class="btn btn-primary">Go Home</a>';
            } else {
                // Show the feedback form if no feedback exists
                echo '<p>We value your feedback and are here to assist with any suggestions you may have to improve our services. Please submit your feedback below.</p>';
        ?>

        <form action="partials/_submitfeedback.php" method="POST">
            <div class="form-group">
                <label for="feedback">Your Feedback</label>
                <textarea class="form-control" id="feedback" name="feedback" rows="5" placeholder="Share your feedback here" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit Feedback</button>
            <a href="index.php" class="btn btn-secondary">Go Back</a>
        </form>

        <?php 
            } // End of else
        } // End of login check
        ?>

        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success mt-3">Your feedback has been submitted successfully.</div>
        <?php elseif (isset($_GET['error']) && $_GET['error'] == 1): ?>
            <div class="alert alert-danger mt-3">There was an error submitting your feedback. Please try again.</div>
        <?php endif; ?>

    </div>

    <?php include 'partials/_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
