<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <style>
        /* General Styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
        }

        h1 {
            text-align: center;
            margin-top: 30px;
            color: #333;
            font-size: 2.5rem;
            font-weight: 700;
        }

        p {
            text-align: center;
            color: #555;
            font-size: 1.1rem;
        }

        /* Container Styles */
        .container {
            max-width: 900px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            transition: all 0.3s ease;
        }

        .container:hover {
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        /* Admin Options */
        .admin-options ul {
            list-style: none;
            padding: 0;
            display: block;
            margin: 0;
        }

        .admin-options li {
            margin: 15px 0;
        }

        .admin-options a {
            text-decoration: none;
            display: block;
            padding: 15px 30px;
            background-color: #942554;
            color: white;
            font-size: 1.2rem;
            font-weight: bold;
            border-radius: 18px;
            text-align: center;
            transition: background-color 0.3s ease, transform 0.2s ease-in-out;
        }

        .admin-options a:hover {
            background-color: #3d2431; /* Darker purple */
            transform: translateY(-5px);
        }

        .admin-options a:active {
            background-color: #4c2681; /* Even darker purple */
            transform: translateY(0);
        }

        /* Footer Styles */
        footer {
            text-align: center;
            margin-top: 30px;
            padding: 20px 0;
            background-color: #333;
            color: white;
        }

        footer a {
            color: #007bff;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <?php
    // Include the header file
    include 'partials/_headeradmin.php';
    ?>

    <div class="container">
        <h1>Welcome!</h1>
        <p>Choose an option below:</p>

        <div class="admin-options">
            <ul>
                <li><a href="partials/add_flight.php">Add Flight</a></li>
                <li><a href="partials/delete_flight.php">Delete Flight</a></li>
                <li><a href="partials/modify_flight.php">Modify Flights</a></li>
                <li><a href="partials/view_booking.php">View Bookings</a></li>
                <li><a href="partials/review_complaints.php">Review Complaints</a></li>
                <li><a href="partials/view_feedback.php">View Feedback</a></li>
                <li><a href="partials/pass_online_checkin.php">Passngers Online Check-In Request</a></li>
            </ul>
        </div>
    </div>

    <?php
    // Include the footer file
    include 'partials/_footer.php';
    ?>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>

</html>
