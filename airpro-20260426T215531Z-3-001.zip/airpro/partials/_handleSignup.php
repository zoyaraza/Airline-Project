<?php
// Start the session at the very beginning to ensure proper session management
session_start();

include '_dbconnect.php'; // Ensure DB connection is included

// Handle form submission logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $email = mysqli_real_escape_string($conn, $_POST['signupemail']);
    $password = mysqli_real_escape_string($conn, $_POST['signuppassword']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['signupconpassword']);
    
    // Check if passwords match
    if ($password !== $confirm_password) {
        // Redirect back with an error message
        header("Location: /db_pro/airpro/index.php?signupsuccess=false&error=Passwords do not match");
        exit(); // Always call exit() after header
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert user into the database
    $sql = "INSERT INTO user(first_name, last_name, email, password) VALUES ('$firstname', '$lastname', '$email', '$hashed_password')";
    if (mysqli_query($conn, $sql)) {
        // Log the user in (start session and set session variables)
        $user_id = mysqli_insert_id($conn); // Get the ID of the newly created user
        $_SESSION['loggedin'] = true; // Mark user as logged in
        $_SESSION['user_id'] = $user_id; // Store user ID in session
        $_SESSION['user_email'] = $email; // Store email for convenience
        $_SESSION['user_name'] = $firstname . ' ' . $lastname; // Store user's full name

        // Redirect to the page they were on before or homepage
        if (isset($_SERVER['HTTP_REFERER'])) {
            header("Location: " . $_SERVER['HTTP_REFERER']);
        } else {
            header("Location: /db_pro/airpro/index.php?signupsuccess=true"); // Default redirect if no referer
        }
        exit(); // Always call exit() after header
    } else {
        // Redirect on failure
        header("Location: /db_pro/airpro/index.php?signupsuccess=false&error=Database error");
        exit();
    }
}
?>
