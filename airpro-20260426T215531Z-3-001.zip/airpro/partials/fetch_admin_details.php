<?php
include '_dbconnect.php';

// New admin details to insert
$username = 'raheen';
$email = 'raheen@gmail.com';
$password = 'raheen123'; // Hardcoded plain password

// Hash the new password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert the new admin into the database
$insert_sql = "INSERT INTO `admin` (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
if (mysqli_query($conn, $insert_sql)) {
    echo "New admin inserted successfully.<br>";
} else {
    echo "Error inserting admin: " . mysqli_error($conn) . "<br>";
    exit();
}

// Fetch the inserted admin details
$fetch_sql = "SELECT email, password FROM `admin` WHERE email = '$email'";
$result = mysqli_query($conn, $fetch_sql);

if ($result && mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    
    // Fetch the email and hashed password
    $db_email = $row['email'];
    $db_hashed_password = $row['password'];
    
    // Display the retrieved details
    echo "Email from Database: " . htmlspecialchars($db_email) . "<br>";
    echo "Hashed Password from Database: " . htmlspecialchars($db_hashed_password) . "<br>";
    
    // Verify if the hardcoded password matches the hashed password
    if (password_verify($password, $db_hashed_password)) {
        echo "Password is correct!";
    } else {
        echo "Incorrect password!";
    }
} else {
    echo "Admin not found or invalid email.";
}
?>
