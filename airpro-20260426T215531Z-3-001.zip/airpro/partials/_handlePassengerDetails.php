<?php
// Start the session and include the database connection
session_start();
include '_dbconnect.php';

// Check if the user is logged in, else redirect
if (!isset($_SESSION['user_id'])) {
    die("Error: No user session found. Please log in again.");
}

// Get the flight_id and seat_count from URL
$flight_id = $_GET['flight_id'];
$seat_count = $_GET['seat_count'];

// Get the user_id from session
$user_id = $_SESSION['user_id'];

// Retrieve the booking_id from the booking table
$sql_booking = "SELECT booking_id FROM booking WHERE user_id = '$user_id' AND flight_id = '$flight_id' ORDER BY booking_id DESC LIMIT 1";
$result_booking = mysqli_query($conn, $sql_booking);

if (mysqli_num_rows($result_booking) > 0) {
    // Fetch the booking_id for the current user and flight
    $row_booking = mysqli_fetch_assoc($result_booking);
    $booking_id = $row_booking['booking_id'];
} else {
    // Handle case where no booking exists for this user and flight
    header("Location: _passenger_details.php?flight_id=$flight_id&seat_count=$seat_count&error=No booking found for this flight");
    exit;
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fetch the base price of the flight
    $sql_flight_price = "SELECT price FROM flight WHERE flight_id = '$flight_id'";
    $result_flight_price = mysqli_query($conn, $sql_flight_price);
    $row_flight_price = mysqli_fetch_assoc($result_flight_price);
    $base_price = $row_flight_price['price'];

    // Initialize a variable to hold the total price for all passengers
    $total_price = 0.00;

    // Loop through each passenger's data and insert into the database
    for ($i = 1; $i <= $seat_count; $i++) {
        // Sanitize user inputs for each passenger
        $first_name = mysqli_real_escape_string($conn, $_POST["first_name_$i"]);
        $last_name = mysqli_real_escape_string($conn, $_POST["last_name_$i"]);
        $dob = mysqli_real_escape_string($conn, $_POST["dob_$i"]);
        $passport = mysqli_real_escape_string($conn, $_POST["passport_$i"]);
        $phone = mysqli_real_escape_string($conn, $_POST["phone_$i"]);
        $nationality = mysqli_real_escape_string($conn, $_POST["nationality_{$i}"]);
        $class_type = mysqli_real_escape_string($conn, $_POST["class_type_$i"]);

        // Calculate the price based on class type
        $price_adjustment = 0;
        if ($class_type === 'Business') {
            $price_adjustment = 100.00;
        } elseif ($class_type === 'First Class') {
            $price_adjustment = 200.00;
        }
        $final_price = $base_price + $price_adjustment;

        // Add the final price to the total price
        $total_price += $final_price;

        // Insert passenger into the database with the retrieved booking_id and class_type
        $sql_passenger = "INSERT INTO passenger (first_name, last_name, date_of_birth, passport_number, phone, nationality, booking_id, class_type, price , flight_id)
                          VALUES ('$first_name', '$last_name', '$dob', '$passport', '$phone', '$nationality', '$booking_id', '$class_type', '$final_price', '$flight_id')";

        if (!mysqli_query($conn, $sql_passenger)) {
            // Error inserting passenger, redirect back with error message
            header("Location: _passenger_details.php?flight_id=$flight_id&seat_count=$seat_count&error=Error inserting passenger details");
            exit;
        }
    }

    // Update the total price in the booking table
    $sql_update_booking = "UPDATE booking SET total_price = '$total_price' WHERE booking_id = '$booking_id'";

    if (!mysqli_query($conn, $sql_update_booking)) {
        // Error updating booking, redirect back with error message
        header("Location: _passenger_details.php?flight_id=$flight_id&seat_count=$seat_count&error=Error updating booking with total price");
        exit;
    }

    // Redirect to the payment page after passengers are added and total price is updated
    header("Location: _payment.php?flight_id=$flight_id&seat_count=$seat_count&booking_id=$booking_id");
    exit;
}
?>
