<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '_dbconnect.php';

    $user_id = $_POST['user_id'];
    $complaint_status = $_POST['complaint_status'];

    // Update complaint status in the database
    $query = "UPDATE user SET complaint_status = ? WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $complaint_status, $user_id);

    if ($stmt->execute()) {
        header("Location: review_complaints.php?success=1");
    } else {
        header("Location: review_complaints.php?error=1");
    }

    $stmt->close();
    $conn->close();
}
?>
