<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '_dbconnect.php';
    $email = $_POST['loginemail'];
    $pass = $_POST['loginpass'];

    $sql = "SELECT * FROM `admin` WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $numRows = mysqli_num_rows($result);

    // Check if admin exists
    if ($numRows == 1) {
        $row = mysqli_fetch_assoc($result);
        // Verify the password
        if (password_verify($pass, $row['password'])) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['adminemail'] = $email;
            $_SESSION['admin_id'] = $row['admin_id'];  
            $_SESSION['user_role'] = 'admin' ;

            // Redirect back with a success message
            $referrer = '../_admin.php';
            header("Location: $referrer?adminlogin=success");
            exit();
        } else {
            // Redirect back with an error message
            $referrer = $_SERVER['HTTP_REFERER'] ?? '/index.php';
            header("Location: $referrer?adminlogin=error");
            exit();
        }
    } else {
        // Redirect back with an error message
        $referrer = $_SERVER['HTTP_REFERER'] ?? '/index.php';
        header("Location: $referrer?adminlogin=error");
        exit();
    }
}
?>
