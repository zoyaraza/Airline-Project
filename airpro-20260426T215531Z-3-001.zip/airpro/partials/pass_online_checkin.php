<?php
// Include the database connection
include '_dbconnect.php';  

// Fetch pending passengers with their booking_id
$query = "SELECT passenger_id, first_name, last_name, booking_id FROM passenger WHERE checkin_status = 'Pending'"; // Query to fetch pending passengers
$stmt = $conn->prepare($query);  // Prepare the statement
$stmt->execute();  // Execute the query
$result = $stmt->get_result();  // Get the result set

// Fetch all pending passengers
$pendingPassengers = $result->fetch_all(MYSQLI_ASSOC);  // Convert result to an associative array
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Online Check-In</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<?php include '_headeradmininside.php'; ?>

<body>
    <div class="container mt-5">
        <h2>Check-In Request</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Passenger ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Booking ID</th>
                    <th>Check-In Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingPassengers as $passenger): ?>
                    <tr id="row-<?= $passenger['passenger_id'] ?>">
                        <td><?= $passenger['passenger_id'] ?></td>
                        <td><?= $passenger['first_name'] ?></td>
                        <td><?= $passenger['last_name'] ?></td>
                        <td><?= $passenger['booking_id'] ?></td>
                        <td id="status-<?= $passenger['passenger_id'] ?>" class="text-warning">Pending</td>
                        <td>
                            <button class="btn btn-success check-in-btn" data-passenger-id="<?= $passenger['passenger_id'] ?>">Mark as Checked In</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function () {
            // When the "Mark as Checked In" button is clicked
            $('.check-in-btn').click(function (e) {
                e.preventDefault(); // Prevent default form submission

                var passengerId = $(this).data('passenger-id'); // Get the passenger id

                $.ajax({
                    url: 'update_checkin_status.php', // PHP script to update check-in status
                    type: 'POST',
                    data: {
                        check_in_online: true,
                        passenger_id: passengerId,
                    },
                    success: function (response) {
                        var data = JSON.parse(response); // Parse the response

                        if (data.status == 'success') {
                            // Update the passenger's check-in status to Checked In in the UI
                            $('#status-' + data.passenger_id).html('Checked In').removeClass('text-warning').addClass('text-success');
                            $('#row-' + data.passenger_id).find('.check-in-btn').prop('disabled', true); // Disable the button after marking checked in
                        }
                    },
                    error: function () {
                        alert("Error updating check-in status.");
                    }
                });
            });
        });
    </script>
     <div class="mt-10 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
</body>
</html>
