<?php
session_start();

// Include database connection
include '_dbconnect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <style>
        .container {
            margin-top: 50px;
        }

        .table {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #942454;
        }

        .btn-primary {
            background-color: #942454;
            border-color: #942454;
        }

        .btn-primary:hover {
            background-color: #701a3f;
            border-color: #701a3f;
        }
    </style>
</head>

<body>
    <?php include '_headeradmininside.php'; ?>

    <div class="container">
        <h2 class="text-center mb-4">User Feedback</h2>

        <?php
        // Fetch feedback from the database (without the feedback date)
        $query = "SELECT user_id, first_name, feedback FROM user WHERE feedback IS NOT NULL";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            echo '<table class="table table-bordered">';
            echo '<thead class="thead-dark">';
            echo '<tr>';
            echo '<th>#</th>';
            echo '<th>User ID</th>';
            echo '<th>Username</th>';
            echo '<th>Feedback</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';

            $count = 1;
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $count++ . '</td>';
                echo '<td>' . htmlspecialchars($row['user_id']) . '</td>';
                echo '<td>' . htmlspecialchars($row['first_name']) . '</td>';
                echo '<td>' . nl2br(htmlspecialchars($row['feedback'])) . '</td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
        } else {
            echo '<div class="alert alert-info">No feedback has been submitted yet.</div>';
        }
        ?>

        <div class="mt-4 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
