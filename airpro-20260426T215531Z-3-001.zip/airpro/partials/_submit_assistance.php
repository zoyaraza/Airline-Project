<?php
include '_dbconnect.php'; // Adjust this path as needed to include your database connection file.

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $passenger_id = $_POST['passenger_id'];
    $assistance_type = $_POST['assistance_type'];

    if (!empty($passenger_id) && !empty($assistance_type)) {
        // Check if the passenger ID exists
        $check_query = "SELECT passenger_id FROM passenger WHERE passenger_id = ?";
        $stmt = $conn->prepare($check_query);
        $stmt->bind_param("i", $passenger_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Update the special assistance request in the passenger table
            $update_query = "UPDATE passenger SET special_ass = ? WHERE passenger_id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("si", $assistance_type, $passenger_id);

            if ($stmt->execute()) {
                header("Location: ../specialassistance.php?message=success");
                exit();
            } else {
                header("Location: ../specialassistance.php?message=error");
                exit();
            }
            
        } else {
            header("Location: ../specialassistance.php?message=notfound");
        }

        $stmt->close();
    } else {
        header("Location: ../specialassistance.php?message=missingfields");
    }

    $conn->close();
}
?>
