<?php
session_start();
include '_dbconnect.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redeem Rewards</title>
   <!-- Required meta tags -->
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }
        .card {
            background-color: #ffffff;
        }
        .card-title {
            color: #007bff;
            font-weight: bold;
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .container {
            margin-top: 50px;
        }
        .navbar {
            margin-bottom: 50px;
        }
        .navbar-brand {
            color: #007bff;
        }
        .navbar-nav .nav-link {
            color: #555;
        }
        .navbar-nav .nav-link:hover {
            color: #007bff;
        }
    </style>
</head>
<body>
<?php include '_headerinside.php';?>

<!-- Page content -->
<div class="container my-4">
    <h3 class="text-center mb-4">Confirm Reward Redemption</h3>

    <?php

    // Check if the reward is passed in the POST request
    if (isset($_POST['reward']) && isset($_POST['points'])) {
        $reward = $_POST['reward'];
        $points = (int)$_POST['points'];
        
        // Fetch user's loyalty points and email
        $user_id = $_SESSION['user_id'];
        $sql = "SELECT loyalty_points, email FROM user WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($loyalty_points, $email);
        $stmt->fetch();
        $stmt->close();


        // Check if the user has enough points
        if ($loyalty_points >= $points) {
            $remaining_points = $loyalty_points - $points;
            $_SESSION['loyalty_points'] = $remaining_points;  // Refresh session loyalty points

            ?>
            <div class="card shadow-sm p-4">
                <div class="card-body">
                    <h4 class="card-title">Reward Details</h4>
                    <ul class="list-group list-group-flush mb-3">
                        <li class="list-group-item"><strong>Reward:</strong> <?php echo $reward; ?></li>
                        <li class="list-group-item"><strong>Points Required:</strong> <?php echo $points; ?> Points</li>
                        <li class="list-group-item"><strong>Remaining Loyalty Points:</strong> <?php echo $remaining_points; ?> Points</li>
                    </ul>

                    <form method="POST" action="confirm_redeem.php">
                        <input type="hidden" name="reward" value="<?php echo $reward; ?>">
                        <input type="hidden" name="points_required" value="<?php echo $points; ?>">
                        <input type="hidden" name="remaining_points" value="<?php echo $remaining_points; ?>">
                        <input type="hidden" name="email" value="<?php echo $email; ?>"> <!-- Email fetched from DB -->
                        <button type="submit" class="btn btn-success btn-lg w-100">Confirm Redeem</button>
                    </form>
                </div>
            </div>
            <?php
        } else {
            echo "<div class='alert alert-danger text-center my-4'>You don't have enough points to redeem this reward.</div>";
        }
    } else {
        echo "<div class='alert alert-danger text-center my-4'>Invalid request. Please try again.</div>";
    }
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
<!-- Footer -->
<?php include '_footer.php'?>

<!-- Bootstrap JS (CDN) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-vyyJmsRf4vDTHf4PzEdLOhEFiEVFdmJfvQIljlTi2TboVt9KlD4n0ELJhR6sdch5" crossorigin="anonymous"></script>
</body>
</html>
