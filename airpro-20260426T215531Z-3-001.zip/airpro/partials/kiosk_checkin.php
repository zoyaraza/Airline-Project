<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f8f9fa;
        }
        .header-title {
            font-weight: 700;
            margin: 20px 0;
        }
        .container {
            margin-top: 50px;
        }
        .info-card {
            background: #fff;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .map-embed {
            border: none;
            width: 100%;
            height: 400px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .cta-btn {
            margin-top: 20px;
            padding: 12px 25px;
        }
        footer {
            background-color: #343a40;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
<?php
    // Check if the user is logged in and whether they are an admin

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}
?><?php include '_dbconnect.php'; ?>   

    <!-- Main Content -->
    <div class="container">
        <h1 class="header-title text-center">Locate a Kiosk</h1>
        <p class="text-center lead">Find the nearest FAST Airways kiosk for a smooth check-in experience.</p>

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="info-card">
                    <h3 class="text-center">Kiosk Location at Terminal 1</h3>
                    <p>Our main kiosk is located at Terminal 1, near Gate 12. This state-of-the-art kiosk provides easy access to all check-in functionalities, including printing boarding passes and luggage tags.</p>
                    
                    <!-- Interactive Map (embedded Google Maps iframe) -->
                    <iframe 
                        class="map-embed"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.2812242379296!2d-122.38997728431818!3d37.61463597978796!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x808f7699f93ad5b7%3A0xe07f3268db9f0bcd!2sSan%20Francisco%20International%20Airport%20(SFO)!5e0!3m2!1sen!2sus!4v1699703565719!5m2!1sen!2sus"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                    
                    <p class="mt-4">For detailed directions to this kiosk, please ask our airport staff or refer to the interactive map above.</p>
                    <a href="_checkin.php" class="btn btn-primary cta-btn"style="border-radius: 50px; font-size: 16px; padding: 15px 30px; background-color: #902454; border-color: #902454;">Back to Check-In Options</a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
</script>
    <?php include '_footer.php'; ?>


    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
