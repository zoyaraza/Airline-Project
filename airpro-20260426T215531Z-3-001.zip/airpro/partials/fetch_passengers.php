<?php
// Include database connection
include '_dbconnect.php'; 

// Get booking ID from POST request
$booking_id = $_POST['booking_id'];

// Fetch passengers for the selected booking
$query = "SELECT p.passenger_id, p.first_name, p.last_name 
          FROM passengers p 
          JOIN tickets t ON p.passenger_id = t.passenger_id
          WHERE t.booking_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $booking_id);
$stmt->execute();
$passengers = $stmt->get_result();

// Create the options for the passenger dropdown
if ($passengers->num_rows > 0) {
    while ($passenger = $passengers->fetch_assoc()) {
        echo "<option value='" . $passenger['passenger_id'] . "'>" . $passenger['first_name'] . " " . $passenger['last_name'] . "</option>";
    }
} else {
    echo "<option value='' disabled>No passengers found</option>";
}
?>
