<?php
// Include database connection
include '_dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passenger_id = $_POST['passenger_id'];
    $meal = $_POST['meal'];

    // Validate input
    if (!empty($passenger_id) && !empty($meal)) {
        // Check if the passenger exists
        $sql_check = "SELECT * FROM passenger WHERE passenger_id = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("i", $passenger_id);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows > 0) {
            // Update the meal preference
            $sql_update = "UPDATE passenger SET prebook_meal = ? WHERE passenger_id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param("si", $meal, $passenger_id);

            if ($stmt_update->execute()) {
                // Redirect with success message
                header("Location:../prebookmeals.php?message=success");
                exit();
            } else {
                // Redirect with error message
                header("Location:../prebookmeals.php?message=error");
                exit();
            }
        } else {
            // Redirect with not found message
            header("Location:../prebookmeals.php?message=notfound");
            exit();
        }
    } else {
        // Redirect with missing fields message
        header("Location:../prebookmeals.php?message=missingfields");
        exit();
    }
}
?>
