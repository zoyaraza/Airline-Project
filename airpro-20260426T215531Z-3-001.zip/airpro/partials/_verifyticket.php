<?php
include '_dbconnect.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $booking_id = $_POST['booking_id'];
    $user_code = $_POST['verification_code'];

    // Fetch the stored verification code for the booking
    $sql = "SELECT verification_code FROM ticket WHERE booking_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $stored_code = $row['verification_code'];

        // Check if the entered code matches the stored code
        if ($user_code == $stored_code) {
            // Update ticket status to 'Confirmed'
            $sql_update = "UPDATE ticket SET status = 'Confirmed' WHERE booking_id = ?";
            $stmt_update = $conn->prepare($sql_update);
            $stmt_update->bind_param("i", $booking_id);
            $stmt_update->execute();

            echo "Ticket verified successfully!";
        } else {
            echo "Invalid verification code. Please try again.";
        }
    } else {
        echo "No ticket found for this booking ID.";
    }

    $stmt->close();
    $conn->close();
}
?>
