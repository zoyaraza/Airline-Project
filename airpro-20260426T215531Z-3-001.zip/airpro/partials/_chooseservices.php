<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Choose Services - Airline Booking</title>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            margin-top: 50px;
        }

        .btn-service {
            margin: 10px;
            background-color: #902454;
            border-color: #902454;
            color: #fff;
        }

        .btn-service:hover {
            background-color: #7c1f40;
            border-color: #7c1f40;
        }
        
        .btn-home {
            margin: 10px;
            background-color: #902454;
            border-color: #902454;
            color: #fff;
        }

        .btn-home:hover {
            background-color: #7c1f40;
            border-color: #7c1f40;
        }
        .service-card img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .service-card {
            margin-bottom: 20px;
        }
    </style>
</head>
<?php include '_headerinside.php'; ?>

<body>

    <div class="container text-center">
        <h1 class="mb-4">Choose Your Services</h1>
        <p>Select from the options below:</p>

        <div class="row">
            <div class="col-md-6 service-card">
                <img src="https://ichef.bbci.co.uk/food/ic/food_16x9_832/recipes/spicy_salmon_bite_rice_16300_16x9.jpg" alt="Pre-book Meals" class="img-fluid">
                <a href="../prebookmeals.php?booking_id=<?php echo $_GET['booking_id']; ?>" class="btn btn-service">Pre-book Meals</a>
            </div>
            <div class="col-md-6 service-card">
                <img src="https://wheelchairtravel.org/content/images/wp-content/uploads/2020/01/faq-air-special-assistance-v2020-header-scaled.jpg" alt="Special Assistance" class="img-fluid">
                <a href="../specialassistance.php?booking_id=<?php echo $_GET['booking_id']; ?>" class="btn btn-service">Special Assistance</a>
            </div>
        </div>
        <a href="../index.php" class="btn btn-home">Go to Home</a>

    </div>
</body>
<?php include '_footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

</html>
