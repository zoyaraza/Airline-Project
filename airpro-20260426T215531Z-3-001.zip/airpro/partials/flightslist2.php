<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Travel The World - FAST Airways</title>
    <style>
        /* Same CSS from flightslist.php */
        body {
            font-family: 'Arial', sans-serif;
        }

        .jumbotron {
            color: white;
            text-align: center;
            padding: 150px 20px;
            position: relative;
        }

        .jumbotron::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .jumbotron .container {
            position: relative;
            z-index: 2;
        }

        .flight-card {
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .flight-card .departure-arrival {
            padding: 15px;
            background: #f8f9fa;
        }

        .flight-card .flight-info {
            text-align: center;
        }

        .flight-card .flight-price {
            padding: 15px;
            background: #fff;
            border-top: 1px solid #ddd;
        }

        .flight-card .flight-price h3 {
            font-weight: bold;
            color: #007bff;
        }

        .flight-path img.plane-icon {
            width: 100px;
            height: auto;
        }

        @media (max-width: 768px) {
            .flight-card .departure-arrival {
                flex-wrap: wrap;
            }

            .flight-card .vertical-line {
                display: none;
            }
        }
    </style>
</head>
<body>
<?php
    // Check if the user is logged in and whether they are an admin
    session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}
?>
    <?php include '_dbconnect.php'; ?>

    <?php
    // Validate and retrieve URL parameters
    if (isset($_GET['from']) && is_numeric($_GET['from']) && isset($_GET['to']) && is_numeric($_GET['to'])) {
        $from_city_id = intval($_GET['from']);
        $to_city_id = intval($_GET['to']);
    } else {
        echo "<p>Departure or Destination City not specified or invalid!</p>";
        exit;
    }

    // Fetch details for both cities
    $from_city_sql = "SELECT * FROM city WHERE city_id = ?";
    $to_city_sql = "SELECT * FROM city WHERE city_id = ?";

    $stmt = $conn->prepare($from_city_sql);
    $stmt->bind_param("i", $from_city_id);
    $stmt->execute();
    $from_city_result = $stmt->get_result();
    $stmt->close();

    $stmt = $conn->prepare($to_city_sql);
    $stmt->bind_param("i", $to_city_id);
    $stmt->execute();
    $to_city_result = $stmt->get_result();
    $stmt->close();

    if ($from_city_result->num_rows > 0 && $to_city_result->num_rows > 0) {
        $from_city = $from_city_result->fetch_assoc();
        $to_city = $to_city_result->fetch_assoc();

        $from_city_name = htmlspecialchars($from_city['name']);
        $to_city_name = htmlspecialchars($to_city['name']);
        $to_city_image_url = htmlspecialchars($to_city['image_url']);
    } else {
        echo "<p>One or both cities not found!</p>";
        exit;
    }
    ?>

    <div class="jumbotron" style="background: url('<?php echo $to_city_image_url; ?>') no-repeat center center; background-size: cover;">
        <div class="container">
            <h1 class="display-4">Flights From <?php echo $from_city_name; ?></h1>
            <h2>To <?php echo $to_city_name; ?></h2>
            <hr class="my-4">
        </div>
    </div>

    <div class="container">
        <div class="row">
            <?php
            // Fetch flights from departure to arrival city
            $flights_sql = "SELECT * FROM flight WHERE departure_city = ? AND arrival_city = ?";
            $stmt = $conn->prepare($flights_sql);
            $stmt->bind_param("ii", $from_city_id, $to_city_id);
            $stmt->execute();
            $flights_result = $stmt->get_result();

            if ($flights_result->num_rows > 0) {
                while ($flight = $flights_result->fetch_assoc()) {
                    $departure_date = htmlspecialchars($flight['departure_date']);
                    $arrival_date = htmlspecialchars($flight['arrival_date']);
                    $departure_time = date("H:i", strtotime($flight['departure_time']));
                    $arrival_time = date("H:i", strtotime($flight['arrival_time']));
                    $price = htmlspecialchars($flight['price']);
                    $total_seats = htmlspecialchars($flight['total_seats']);
                    $available_seats = htmlspecialchars($flight['available_seats']);
                    $flight_number = htmlspecialchars($flight['flight_number']);
                    $flight_id = $flight['flight_id'];

                    echo '
                    <div class="col-md-12 mb-3">
                        <div class="flight-card">
                            <div class="departure-arrival d-flex justify-content-around">
                                <div class="flight-info">
                                    <strong>Departure:</strong><br>
                                    ' . $from_city_name . '<br>
                                    <strong>Date:</strong> ' . $departure_date . '<br>
                                    <strong>Time:</strong> ' . $departure_time . '
                                </div>
                                <div class="flight-path d-flex align-items-center">
                                    <img src="https://www.freeiconspng.com/thumbs/airplane-icon-png/plane-icon-png-images--pictures--becuo-8.png" alt="Plane" class="plane-icon">
                                </div>
                                <div class="flight-info">
                                    <strong>Arrival:</strong><br>
                                    ' . $to_city_name . '<br>
                                    <strong>Date:</strong> ' . $arrival_date . '<br>
                                    <strong>Time:</strong> ' . $arrival_time . '
                                </div>
                            </div>
                            <div class="flight-price text-center">
                                <h3>$ ' . $price . '</h3>
                                <p>Total Seats: ' . $total_seats . '</p>
                                <p>Available Seats: ' . $available_seats . '</p>';
                    if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
                        echo '<button class="btn btn-primary" onclick="showLoginModal()">Book Now</button>';
                        
                    } else {
                        echo '<a href="/db_pro/airpro/partials/_booking.php?flight_id=' . $flight_id . '" class="btn btn-primary">Book Now</a>';
                    }
                    echo '</div></div></div>';
                }
            } else {
                echo '<div class="col-12 text-center"><p>No flights available for this route.</p></div>';
            }
            $stmt->close();
            ?>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="LoginModel_1" tabindex="-1" role="dialog" aria-labelledby="LoginModelLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="LoginModelLabel">Login or Signup</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                <p>Please login or sign up to book flights.</p>
                <button class="btn btn-primary mx-2" style="border: none;" data-toggle="modal" data-target="#LoginModel" data-dismiss="modal">Login</button>
                <button class="btn btn-primary mx-2" style="border: none;" data-toggle="modal" data-target="#signupModel" data-dismiss="modal">SignUp</button>
            </div>
            </div>
        </div>
    </div>
    
    <?php include '_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfOijehtPH0lsSSs5nCTpuj/zyM6X8Y8z1mPtDKtW1n2Fw8hP67r56Q4j6z" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-VpOjeJ5U0rs69R5o6j8z1YOzZXtLhI0lz5e9SsdO7JhH4ZoYEl/NejlAiWz2NeF5" crossorigin="anonymous"></script>

    <script>
    function showLoginModal() {
        // Show the login/signup modal
        $('#LoginModel_1').modal('show');
    }
</script>

</body>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">

    </script>
