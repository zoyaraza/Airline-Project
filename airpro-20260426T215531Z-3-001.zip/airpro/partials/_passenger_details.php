<?php
// Start the session and include the database connection
session_start();
include '_dbconnect.php';

if (!isset($_SESSION['user_id'])) {
    die("Error: No user session found. Please log in again.");
}

$flight_id = $_GET['flight_id'];
$seat_count = $_GET['seat_count'];

// Fetch flight price for base economy class
$sql_flight = "SELECT price FROM flight WHERE flight_id = '$flight_id'";
$result_flight = mysqli_query($conn, $sql_flight);
if ($result_flight && mysqli_num_rows($result_flight) > 0) {
    $row_flight = mysqli_fetch_assoc($result_flight);
    $base_price = $row_flight['price'];
} else {
    die("Error: Unable to retrieve flight details.");
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Passenger Details - FAST Airways</title>
    <style>
        .form-section {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .page-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-primary {
            width: 100%;
            padding: 12px;
            background-color: #902454;
            border: none;
        }

        .btn-primary:hover {
            background-color: #7c1f40; /* Slightly darker shade for hover effect */
        }

        .alert-custom {
            background-color: #e3f2fd;
            color: #0d47a1;
        }
    </style>
</head>

<body>
<?php include '_headerinside.php'; ?>

    <div class="container my-5">
        <h2 class="text-center mb-4">Passenger Details</h2>

        <div class="form-section">
            <p class="lead text-center">Please enter the details of all passengers for your booking.</p>

            <!-- Error Message -->
            <?php if (isset($_GET['error'])) { echo '<div class="alert alert-custom">' . htmlspecialchars($_GET['error']) . '</div>'; } ?>

            <form action="_handlePassengerDetails.php?flight_id=<?php echo $flight_id; ?>&seat_count=<?php echo $seat_count; ?>" method="POST">
                <?php for ($i = 1; $i <= $seat_count; $i++): ?>
                    <div class="form-section">
                        <h5>Passenger <?php echo $i; ?></h5>
                        <div class="form-group">
                            <label for="first_name_<?php echo $i; ?>">First Name</label>
                            <input type="text" class="form-control" id="first_name_<?php echo $i; ?>" name="first_name_<?php echo $i; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name_<?php echo $i; ?>">Last Name</label>
                            <input type="text" class="form-control" id="last_name_<?php echo $i; ?>" name="last_name_<?php echo $i; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="dob_<?php echo $i; ?>">Date of Birth</label>
                            <input type="date" class="form-control" id="dob_<?php echo $i; ?>" name="dob_<?php echo $i; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="passport_<?php echo $i; ?>">Passport Number</label>
                            <input type="text" class="form-control" id="passport_<?php echo $i; ?>" name="passport_<?php echo $i; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="phone_<?php echo $i; ?>">Phone Number</label>
                            <input type="text" class="form-control" id="phone_<?php echo $i; ?>" name="phone_<?php echo $i; ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="nationality<?php echo $i; ?>">Nationality</label>
                            <input type="text" class="form-control" id="nationality_<?php echo $i; ?>" name="nationality_<?php echo $i; ?>" required>
                            </div>

                        <!-- Class Type Selection -->
                        <div class="form-group">
                            <label for="class_type_<?php echo $i; ?>">Class Type</label>
                            <select class="form-control" id="class_type_<?php echo $i; ?>" name="class_type_<?php echo $i; ?>" required>
                                <option value="Economy" data-price="<?php echo $base_price; ?>">Economy ($<?php echo $base_price; ?>)</option>
                                <option value="Business" data-price="<?php echo $base_price + 100; ?>">Business ($<?php echo $base_price + 100; ?>)</option>
                                <option value="First Class" data-price="<?php echo $base_price + 200; ?>">First Class ($<?php echo $base_price + 200; ?>)</option>
                            </select>
                        </div>
                    </div>
                <?php endfor; ?>

                <!-- Submit Button -->
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Submit Passenger Details</button>
                </div>
            </form>
        </div>

    </div>

    <?php include '_footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
