<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Your Tickets - Airline Booking</title>
    <style>
        /* Global styles */
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .jumbotron {
            background-color: #902454;
            color: white;
            text-align: center;
            padding: 50px 20px;
        }

        .container h3 {
            color: #902454;
            font-weight: bold;
        }

        /* Ticket Card */
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: none;
            margin-bottom: 20px;
        }

        .card-title {
            color: #902454;
            font-weight: bold;
        }

        .btn-primary {
            background-color: #902454;
            border: none;
        }

        .btn-primary:hover {
            background-color: #7c1f40;
        }

        .alert-info,
        .alert-success,
        .alert-danger {
            font-weight: bold;
        }

        /* Footer */
        footer {
            background-color: #902454;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
    </style>
</head>


  <!-- Header -->
  <?php include '_headerinside.php'; ?>

<!-- Jumbotron -->
<div class="jumbotron">
    <div class="container">
        <h1>Your Booking Tickets</h1>
        <p>Details of your booking are listed below. Please verify your tickets.</p>
    </div>
</div>

<div class="container my-4">
<?php
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/SMTP.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Database connection
include '_dbconnect.php';   
if (!isset($_SESSION['user_id'])) {
    die("Error: No user session found. Please log in again.");
}


// Check if booking_id is passed
if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];
} else {
    die("Error: Booking ID not found.");
}

// Email function
function sendEmail($email, $subject, $body) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'airlineproject18@gmail.com';
        $mail->Password   = 'vhtf imfw viop zgkg'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('airlineproject18@gmail.com', 'Airline Tickets');
        $mail->addAddress($email);

        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        // Send email
        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        return false; // Failed to send email
    }
}
// Retrieve passengers and flight details
$sql = "SELECT p.passenger_id, p.first_name, p.class_type, u.email, b.flight_id 
        FROM passenger p 
        INNER JOIN booking b ON p.booking_id = b.booking_id 
        INNER JOIN user u ON b.user_id = u.user_id 
        WHERE b.booking_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $email_body = "";
    $first_passenger = true;
    $verification_token = bin2hex(random_bytes(16)); // Generate token once for the whole booking
    $verification_code = rand(1000, 9999); // Random 4-digit verification code

    echo '<div class="container my-4">';
    echo '<h3>Your Tickets</h3><div class="row">';
    while ($row = $result->fetch_assoc()) {
        $passenger_id = $row['passenger_id'];
        $first_name = $row['first_name'];
        $class_type = $row['class_type'];
        $email = $row['email'];
        $flight_id = $row['flight_id'];

        // Generate seat number (Example logic)
        $seat_number = rand(1, 200); // Example seat number generation
        $status = 'Pending'; // Initial status

        // Generate a 4-digit verification code

        // Insert ticket details along with verification code
        $sql_insert = "INSERT INTO ticket (flight_id, passenger_id, seat_number, booking_id, verification_token, status, verification_code) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param("iiisssi", $flight_id, $passenger_id, $seat_number, $booking_id, $verification_token, $status, $verification_code);

        if (!$stmt_insert->execute()) {
            echo "Error creating ticket for passenger ID $passenger_id: " . $stmt_insert->error . "<br>";

        }
         // Append ticket details to email body
         if ($first_passenger) {
            $email_body .= "For all passengers in this booking, use the following verification code: <br>";
            $email_body .= "Verification Code: $verification_code<br><br>";
            $first_passenger = false;
                
         }
         $email_body .= "
         Passenger Id:$passenger_id<br>
        Passenger Name: $first_name<br>
        Class Type: $class_type<br>
        Seat Number: $seat_number<br>
        Status: Pending<br><br>
        ";

       // Display each passenger's ticket as a card
       echo '<div class="col-md-4">';
       echo '<div class="card">';
       echo '<div class="card-body">';
       echo "<h5 class='card-title'>Passenger: $first_name</h5>";
       echo "<p class='card-text'>Passenger ID: $passenger_id</p>";
       echo "<p class='card-text'>Class: $class_type</p>";
       echo "<p class='card-text'>Seat Number: $seat_number</p>";
       echo "<p class='card-text'>Status: Pending</p>";
       echo '</div>';
       echo '</div>';
       echo '</div>';
    }

    echo '</div>'; // Close row
    echo '</div>'; // Close container

    // Send email
    if (!empty($email_body)) {
        $subject = "Your Booking Tickets";
        $body = "Hello,<br><br>
                 Below are the tickets for your booking ID: $booking_id:<br><br>
                 $email_body<br>
                 Regards,<br>Airline Team";

        if (sendEmail($email, $subject, $body)) {
            echo '<div class="alert alert-success" role="alert">An email with your ticket details has been sent to your email address.</div>';
        }
    }
    // Verification status container
    echo '<div class="alert alert-info" role="alert" id="verification-status" style="display: none;"></div>';

    // Verification form
    echo '<div class="form-group">';
    echo '<label for="verification-code">Enter the Verification Code</label>';
    echo '<input type="text" id="verification-code" class="form-control" placeholder="Verification Code">';
    echo '<button id="verify-tickets-btn" class="btn btn-primary mt-2">Verify Tickets</button>';
    echo '</div>';

    // Verification button script
    echo '<script>
    document.addEventListener("DOMContentLoaded", function () {
        const verifyButton = document.getElementById("verify-tickets-btn");
        const verificationStatus = document.getElementById("verification-status");
        const verificationCodeInput = document.getElementById("verification-code");

        if (verifyButton) {
            verifyButton.addEventListener("click", function () {
                const bookingId = ' . json_encode($booking_id) . ';
                const token = ' . json_encode($verification_token) . ';
                const userCode = verificationCodeInput.value;
                if (userCode) {
                    fetch(`_verifycode.php?booking_id=${bookingId}&verification_code=${userCode}`)
                        .then((response) => response.json())
                        .then((data) => {
                            if (data.success) {
                                verificationStatus.style.display = "block";
                                verificationStatus.classList.add("alert-success");
                                verificationStatus.innerText = data.message;
                                setTimeout(() => {
                                window.location.href = "_chooseservices.php?booking_id=" + bookingId;
                                }, 2000); // Redirect after 2 seconds
                            } else {
                                verificationStatus.style.display = "block";
                                verificationStatus.classList.add("alert-danger");
                                verificationStatus.innerText = data.message;
                            }
                        })
                        .catch((error) => {
                            console.error("Error verifying tickets:", error);
                            verificationStatus.style.display = "block";
                            verificationStatus.classList.add("alert-danger");
                            verificationStatus.innerText = "An error occurred during verification.";
                            });
                } else {
                    verificationStatus.style.display = "block";
                    verificationStatus.classList.add("alert-danger");
                    verificationStatus.innerText = "Please enter a verification code.";
                }
            });
}
             });
    </script>';
} else {
    echo "No passengers found for booking ID $booking_id.";
}
$stmt->close();
$conn->close();
?>
    </div>
  <!-- Footer -->
  <?php include '_footer.php'; ?>

<!-- Script -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const verifyButton = document.getElementById("verify-tickets-btn");
        const verificationStatus = document.getElementById("verification-status");
        const verificationCodeInput = document.getElementById("verification-code");

        verifyButton.addEventListener("click", function () {
            const userCode = verificationCodeInput.value;
            if (userCode) {
                fetch(_verifycode.php?booking_id=<?php echo $booking_id; ?>&verification_code=${userCode})
                    .then((response) => response.json())
                    .then((data) => {
                        verificationStatus.style.display = "block";
                        if (data.success) {
                            verificationStatus.className = "alert alert-success";
                            verificationStatus.textContent = data.message;
                            // Redirect to _chooseservices.php after 2 seconds
                            setTimeout(() => {
                                window.location.href = _chooseservices.php?booking_id=<?php echo $booking_id; ?>;
                            }, 2000);
                        } else {
                            verificationStatus.className = "alert alert-danger";
                            verificationStatus.textContent = data.message;
                        }
                    });
            } else {
                verificationStatus.style.display = "block";
                verificationStatus.className = "alert alert-danger";
                verificationStatus.textContent = "Please enter a verification code.";
            }
        });
    });
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
</script>
</body>

</html>


