<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa; /* Original background color */
            color: #333;
            padding: 0;
            margin: 0;
        }
        .header-title {
            font-weight: 700;
            font-size: 3em;
            text-align: center;
            margin-top: 60px;
            animation: fadeIn 1s ease-out;
        }
        .lead {
            font-size: 1.5em;
            text-align: center;
            margin-top: 20px;
            color: #666;
            animation: fadeIn 1.5s ease-out;
        }
        .app-feature {
            margin-bottom: 50px;
            text-align: center;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0px 15px 40px rgba(0, 0, 0, 0.1);
            opacity: 0;
            animation: fadeInUp 1s forwards;
        }
        .app-feature img {
            width: 100%;
            max-width: 350px;
            border-radius: 10px;
            object-fit: cover;
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }
        .app-feature img:hover {
            transform: scale(1.1); /* Zoom effect on image hover */
        }
        .app-feature h3 {
            font-size: 1.8em;
            color: #333;
            margin-bottom: 10px;
        }
        .app-feature p {
            font-size: 1.1em;
            color: #666;
        }
        .download-btns {
            text-align: center;
            margin-top: 50px;
            animation: fadeInUp 1.2s forwards;
        }
        .download-btns .btn {
            font-size: 1.2em;
            padding: 15px 40px;
            border-radius: 50px;
            margin: 12px;
            background-color: #902454; /* Restored button color */
            border-color: #902454; /* Same border color */
            transition: background-color 0.3s ease;
        }
        .download-btns .btn:hover {
            background-color: #7c1f40; /* Slightly darker shade on hover */
        }
        .faq-section {
            background-color: #ffffff;
            padding: 60px 0;
            box-shadow: 0px 15px 40px rgba(0, 0, 0, 0.1);
            margin-top: 60px;
            border-radius: 15px;
            animation: fadeInUp 1.4s forwards;
        }
        .faq-section h2 {
            font-size: 2.5em;
            margin-bottom: 30px;
            color: #333;
        }
        .faq-section li h5 {
            font-weight: 600;
            font-size: 1.4em;
            color: #333;
        }
        .faq-section li p {
            font-size: 1.2em;
            color: #555;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
<?php
    // Check if the user is logged in and whether they are an admin

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}
?><?php include '_dbconnect.php'; ?>    
    <!-- Main Content -->
    <div class="container">
        <h1 class="header-title">Download the FAST Airways App</h1>
        <p class="lead">Manage your booking, check-in, and access exclusive features with the FAST Airways mobile app.</p>

        <!-- App Features -->
        <div class="row">
            <div class="col-md-4 app-feature">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4KvomIpfm_Oo5-DJxU3Gx88m4l558kYfksw&s" alt="Manage Booking">
                <h3>Manage Your Booking</h3>
                <p>Easily manage your flight bookings, including checking in, selecting seats, and viewing your itinerary.</p>
            </div>
            <div class="col-md-4 app-feature">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwo9nuHbhuh0hPEhN7x7EvdPYV-Nelr8wlmQ&s" alt="Flight Updates">
                <h3>Flight Updates & Notifications</h3>
                <p>Get real-time updates on your flight status, gate changes, and more.</p>
            </div>
            <div class="col-md-4 app-feature">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZYgxq6t9bCgbBomi9jcm6i5cvAhCJtGXf5g&s" alt="Exclusive Offers">
                <h3>Exclusive Offers & Deals</h3>
                <p>Access special discounts and promotions available only to app users.</p>
            </div>
        </div>

        <!-- Download Buttons -->
        <div class="download-btns">
            <a href="https://www.apple.com/app-store/" target="_blank" class="btn btn-primary">Download on the App Store</a>
            <a href="https://play.google.com/store" target="_blank" class="btn btn-danger">Get it on Google Play</a>
        </div>

        <!-- FAQ Section -->
        <div class="faq-section">
            <div class="container">
                <h2 class="text-center">Frequently Asked Questions</h2>
                <ul>
                    <li>
                        <h5>How do I check in through the app?</h5>
                        <p>Simply log in to the app, select your booking, and follow the prompts to check in.</p>
                    </li>
                    <li>
                        <h5>Is the app free to download?</h5>
                        <p>Yes, the FAST Airways app is free to download and use. Enjoy all the features at no cost!</p>
                    </li>
                    <li>
                        <h5>Can I access boarding passes through the app?</h5>
                        <p>Yes, once you check in, your boarding pass will be available directly in the app for easy access at the airport.</p>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <?php include '_footer.php'; ?>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
