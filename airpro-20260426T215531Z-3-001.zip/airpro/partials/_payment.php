<?php
session_start();
include '_dbconnect.php';

// Check if the booking_id is set in the URL
if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];
} else {
    die("Error: No booking ID found.");
}

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: No user session found. Please log in again.");
}

// Retrieve the total price and flight_id from the booking table
$sql_booking_price = "SELECT total_price, flight_id FROM booking WHERE booking_id = '$booking_id'";
$result_booking_price = mysqli_query($conn, $sql_booking_price);

if ($result_booking_price && mysqli_num_rows($result_booking_price) > 0) {
    $row_booking_price = mysqli_fetch_assoc($result_booking_price);
    $total_price = $row_booking_price['total_price'];
    $flight_id = $row_booking_price['flight_id'];
} else {
    die("Error: Booking not found.");
}

$seat_count = isset($_GET['seat_count']) ? $_GET['seat_count'] : 1; // Default to 1 seat if not provided

// Discount-related variables
$discount = 0;
$discount_code = isset($_POST['discount_code']) ? strtoupper(trim($_POST['discount_code'])) : '';
$error_message = '';
$discount_applied = false;

// Define a list of European cities
$european_cities = ['Paris', 'London', 'Frankfurt', 'Brussels', 'Zurich'];

// Fetch the departure city name from the flight table
$sql_flight = "
    SELECT c.name AS departure_city 
    FROM flight f 
    JOIN city c ON f.departure_city = c.city_id 
    WHERE f.flight_id = '$flight_id'";
$result_flight = mysqli_query($conn, $sql_flight);

if ($result_flight && mysqli_num_rows($result_flight) > 0) {
    $row_flight = mysqli_fetch_assoc($result_flight);
    $departure_city = strtolower($row_flight['departure_city']); // Convert to lowercase for comparison

    // Check discount code conditions
    if ($discount_code === 'EUROPE10') {
        $normalized_cities = array_map('strtolower', $european_cities);
        if (in_array($departure_city, $normalized_cities)) {
            $discount = 0.10; // 10% discount
            $discount_applied = true;
        } else {
            $error_message = "Error: EUROPE10 can only be applied to flights departing from European cities.";
        }
    } elseif ($discount_code === 'GROUP5') {
        if ($seat_count > 5) {
            $discount = 0.15; // 15% discount
            $discount_applied = true;
        } else {
            $error_message = "Error: GROUP5 requires a booking of more than 5 passengers.";
        }
    }
}
// Generate a unique transaction ID
$transaction_id = uniqid('txn_', true);

// Define initial payment status
$payment_status = 'Pending';

// Insert payment details into the Payment table
$sql_insert_payment = "
    INSERT INTO payment (amount, transaction_id, status, booking_id)
    VALUES ('$total_price', '$transaction_id', '$payment_status', '$booking_id')
";

if (!mysqli_query($conn, $sql_insert_payment)) {
    die("Error: Could not store payment details. " . mysqli_error($conn));
}

// Fetch the inserted payment ID for further processing (if needed)

$payment_id = mysqli_insert_id($conn);
$booking_id; 
$amount = mysqli_insert_id($conn);
$transaction_id;
$status;
// Assuming $conn is your database connection and $Resident_ID is defined
$query = "SELECT payment_id, amount, transaction_id, status, booking_id FROM payment WHERE booking_id = ?";
if ($stmt = $conn->prepare($query)) {
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $stmt->bind_result($payment_id, $amount, $transaction_id, $status,$booking_id);
    
    // Initialize an empty array to hold billing records
    $paymentRecords = [];
    while ($stmt->fetch()) {
        // Push each record into the array
        $paymentRecords[] = [
            'payment_id' => $payment_id,
            'amount' => $amount,
            'transaction_id' => $transaction_id,
            'status' => $status,
            'booking_id' => $booking_id
        ];
    }
    $stmt->close();

}
// Calculate discounted price
$discounted_price = $total_price - ($total_price * $discount);

// Store payment details in session (if needed)
$_SESSION['payment_details'] = [
    'payment_id' => $payment_id,
    'booking_id' => $booking_id,
    'amount' => $discount_applied ? $discounted_price : $total_price,
    'discount' => $discount
];
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Payment - FAST Airways</title>
    <style>
        .form-section { margin: 20px 0; padding: 20px; border: 1px solid #ccc; border-radius: 10px; background-color: #f9f9f9; }
        .page-header { text-align: center; margin-bottom: 30px; }
        .form-control { border-radius: 5px; }
        .btn-primary { width: 100%; padding: 12px; background-color: #902454; border: none; }
        .btn-primary:hover { background-color: #7c1f40; }
        .alert-error { color: red; font-weight: bold; }
        h4 { color: #902454; }
    </style>
</head>
<body>
<?php include '_headerinside.php'; ?>

<div class="container my-5">
    <div class="page-header">
        <h2>Payment</h2>
        <p class="lead">Please review your booking details and complete your payment.</p>
    </div>

    <!-- Payment Summary -->
    <div class="form-section">
        <h4>Booking Summary</h4>
        <p><strong>Booking ID:</strong> <?php echo htmlspecialchars($booking_id); ?></p>
        <p><strong>Seats Selected:</strong> <?php echo htmlspecialchars($seat_count); ?></p>
        <p><strong>Total Price:</strong> $<?php echo number_format($total_price, 2); ?></p>

        <?php if ($discount_applied) { ?>
            <p><strong>Discount Applied:</strong> <?php echo ($discount * 100); ?>%</p>
            <p><strong>Discounted Price:</strong> $<?php echo number_format($discounted_price, 2); ?></p>
        <?php } else { ?>
            <p><strong>Discount Applied:</strong> None</p>
        <?php } ?>
    </div>

    <!-- Display Error Message -->
    <?php if ($error_message) { ?>
        <div class="alert alert-error"><?php echo $error_message; ?></div>
    <?php } ?>

    <!-- Discount Code Form -->
    <form method="POST">
        <div class="form-group">
            <label for="discount_code">Enter Discount Code:</label>
            <input type="text" id="discount_code" name="discount_code" class="form-control" placeholder="Enter code">
        </div>
        <button type="submit" class="btn btn-primary">Apply Discount</button>
    </form>

    <!-- Proceed to Payment -->
    <form action="_paymentreq.php?booking_id=<?php echo htmlspecialchars($booking_id); ?>" method="POST">
        <button type="submit" class="btn btn-primary mt-3">Proceed to Payment</button>
    </form>
</div>

</body>
</html>
