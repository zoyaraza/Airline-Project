<!-- Modal -->
<div class="modal fade" id="signupModel" tabindex="-1" aria-labelledby="signupModelLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="signupModelLabel">Sign Up</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="/db_pro/airpro/partials/_handleSignup.php" method="post">
        <div class="modal-body">
          
          <!-- Error Message Display -->
          <?php if (isset($_GET['signupsuccess']) && $_GET['signupsuccess'] == 'false'): ?>
            <div class="alert alert-danger" role="alert">
              <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
          <?php endif; ?>

          <!-- First Name -->
          <div class="form-group">
            <label for="firstname">First Name</label>
            <input type="text" class="form-control" id="firstname" name="firstname" required>
          </div>

          <!-- Last Name -->
          <div class="form-group">
            <label for="lastname">Last Name</label>
            <input type="text" class="form-control" id="lastname" name="lastname" required>
          </div>

          <!-- Email -->
          <div class="form-group">
            <label for="signupemail">Email Address</label>
            <input type="email" class="form-control" id="signupemail" name="signupemail" aria-describedby="emailHelp" required>
            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
          </div>

          <!-- Password -->
          <div class="form-group">
            <label for="signuppassword">Password</label>
            <input type="password" class="form-control" id="signuppassword" name="signuppassword" required>
          </div>

          <!-- Confirm Password -->
          <div class="form-group">
            <label for="signupconpassword">Confirm Password</label>
            <input type="password" class="form-control" id="signupconpassword" name="signupconpassword" required>
          </div>
          
          <!-- Submit Button -->
          <button type="submit" class="btn btn-primary">Sign Up</button>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
