<?php
session_start();

// Check if admin is logged in
// if (!isset($_SESSION['adminlogin']) || $_SESSION['adminlogin'] !== true) {
//     header("Location: index.php");
//     exit();
// }

// Include database connection
include '_dbconnect.php';

// Fetch cities from the database
$cities = [];
$sql = "SELECT city_id, name FROM City";
$result = mysqli_query($conn, $sql);

if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $cities[] = $row;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $flight_number = $_POST['flight_number'];
    $departure_city = $_POST['departure_city'];
    $arrival_city = $_POST['arrival_city'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $status = $_POST['status'];
    $available_seats = $_POST['available_seats'];
    $total_seats = $_POST['total_seats'];
    $price = $_POST['price'];
    $departure_date = $_POST['departure_date'];
    $arrival_date = $_POST['arrival_date'];

    // Insert flight into the database
    $sql = "INSERT INTO Flight (flight_number, departure_city, arrival_city, departure_time, arrival_time, status, available_seats, total_seats, price, departure_date, arrival_date) 
            VALUES ('$flight_number', '$departure_city', '$arrival_city', '$departure_time', '$arrival_time', '$status', '$available_seats', '$total_seats', '$price', '$departure_date', '$arrival_date')";

    if (mysqli_query($conn, $sql)) {
        $success = "Flight added successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Flight</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<?php include '_headeradmininside.php';
?>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Add a New Flight</h1>

        <!-- Success/Error Message -->
        <?php if (isset($success)) { ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php } ?>
        <?php if (isset($error)) { ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php } ?>

        <form action="add_flight.php" method="POST">
            <div class="form-group">
                <label for="flight_number">Flight Number</label>
                <input type="text" class="form-control" id="flight_number" name="flight_number" required>
            </div>
            <div class="form-group">
                <label for="departure_city">Departure City</label>
                <select class="form-control" id="departure_city" name="departure_city" required>
                    <option value="" disabled selected>Select a city</option>
                    <?php foreach ($cities as $city) { ?>
                        <option value="<?php echo $city['city_id']; ?>"><?php echo $city['name']; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label for="arrival_city">Arrival City</label>
                <select class="form-control" id="arrival_city" name="arrival_city" required>
                    <option value="" disabled selected>Select a city</option>
                    <?php foreach ($cities as $city) { ?>
                        <option value="<?php echo $city['city_id']; ?>"><?php echo $city['name']; ?></option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label for="departure_date">Departure Date</label>
                <input type="date" class="form-control" id="departure_date" name="departure_date" required>
            </div>
            <div class="form-group">
                <label for="departure_time">Departure Time</label>
                <input type="time" class="form-control" id="departure_time" name="departure_time" required>
            </div>
            <div class="form-group">
                <label for="arrival_date">Arrival Date</label>
                <input type="date" class="form-control" id="arrival_date" name="arrival_date" required>
            </div>
            <div class="form-group">
                <label for="arrival_time">Arrival Time</label>
                <input type="time" class="form-control" id="arrival_time" name="arrival_time" required>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select class="form-control" id="status" name="status">
                    <option value="On-Time">On-Time</option>
                    <option value="Delayed">Delayed</option>
                    <option value="Canceled">Canceled</option>
                </select>
            </div>
            <div class="form-group">
                <label for="available_seats">Available Seats</label>
                <input type="number" class="form-control" id="available_seats" name="available_seats" required>
            </div>
            <div class="form-group">
                <label for="total_seats">Total Seats</label>
                <input type="number" class="form-control" id="total_seats" name="total_seats" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" class="form-control" id="price" name="price" step="0.01" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Flight</button>
        </form>
    </div>
    <div class="mt-4 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
