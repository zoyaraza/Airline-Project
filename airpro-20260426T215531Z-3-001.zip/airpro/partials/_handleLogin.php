<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include '_dbconnect.php';
    $email = $_POST['loginemail'];
    $pass = $_POST['loginpass'];

    $sql = "SELECT * FROM `user` WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $numRows = mysqli_num_rows($result);

    // Check if user exists
    if ($numRows == 1) {
        $row = mysqli_fetch_assoc($result);
        // Verify the password
        if (password_verify($pass, $row['password'])) {
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['useremail'] = $email;
            $_SESSION['user_id'] = $row['user_id'];  // Storing user_id in session

            // Redirect back with a success message
            $referrer = $_SERVER['HTTP_REFERER'] ?? '/index.php'; // Default to homepage if no referrer
            header("Location: $referrer?login=success");
            exit();
        } else {
            // Redirect back with an error message
            $referrer = $_SERVER['HTTP_REFERER'] ?? '/index.php';
            header("Location: $referrer?login=error");
            exit();
        }
    } else {
        // Redirect back with an error message
        $referrer = $_SERVER['HTTP_REFERER'] ?? '/index.php';
        header("Location: $referrer?login=error");
        exit();
    }
}
?>
