<?php
// Include the database connection
include '_dbconnect.php';  

// Check if the AJAX request is sent
if (isset($_POST['check_in_online']) && isset($_POST['passenger_id'])) {
    $passenger_id = $_POST['passenger_id'];  // Get the passenger ID from the POST data

    // Update the check-in status of the passenger
    $query = "UPDATE passenger SET checkin_status = 'Checked-In' WHERE passenger_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $passenger_id);
    
    if ($stmt->execute()) {
        // Success: Return a JSON response
        echo json_encode([
            'status' => 'success',
            'passenger_id' => $passenger_id
        ]);
    } else {
        // Failure: Return a JSON response
        echo json_encode([
            'status' => 'error',
            'message' => 'Error updating check-in status.'
        ]);
    }
} else {
    // If required data is not set, return error
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request.'
    ]);
}
?>
