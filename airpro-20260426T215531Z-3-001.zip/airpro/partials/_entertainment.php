<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
    body {
        font-family: 'Roboto', sans-serif;
        background-color: #f8f9fa;
    }
    .header-title {
        font-weight: 700;
        margin-top: 20px;
        text-align: center;
    }
    .entertainment-card {
        border: none;
        border-radius: 10px;
        transition: transform 0.3s;
    }
    .entertainment-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    .entertainment-card img {
        border-radius: 10px 10px 0 0;
        width: 100%;
        height: 450px; /* Fixed height matching the 'Us' movie image */
        object-fit: cover;
    }
    .entertainment-title {
        font-weight: 700;
        font-size: 1.1rem;
    }
    .entertainment-genre {
        color: #6c757d;
    }
    .filter-bar {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-bottom: 30px;
    }
    .filter-btn {
        border: none;
        background-color: #942454; /* Purple button color */
        color: #fff;
        padding: 10px 20px;
        border-radius: 20px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .filter-btn:hover {
        background-color: #5a32a3; /* Darker purple for hover */
    }
    footer {
        background-color: #343a40; /* Dark background */
        color: #fff;
        text-align: center;
        padding: 20px 0;
        margin-top: 50px;
    }
</style>


</head>
<body>
 
<?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}?><?php include '_dbconnect.php'; ?>  

    <!-- Header -->
    <div class="container mt-5">
        <h1 class="header-title">Inflight Entertainment</h1>
        <p class="lead text-center">Explore a selection of movies, TV shows, songs, and more for your journey.</p>

        <!-- Filter Bar -->
        <div class="filter-bar mb-4">
            <button class="filter-btn" onclick="filterContent('all')">All</button>
            <button class="filter-btn" onclick="filterContent('movie')">Movies</button>
            <button class="filter-btn" onclick="filterContent('tv')">TV Shows</button>
            <button class="filter-btn" onclick="filterContent('documentary')">Documentaries</button>
            <button class="filter-btn" onclick="filterContent('song')">Songs</button>
        </div>

        <!-- Entertainment Cards -->
        <div class="row">
            <!-- Movies -->
            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BMzhkMjFkN2YtODU2Ni00YWYwLWExN2MtOWNjZmQxM2U4YTM5XkEyXkFqcGc@.V1_FMjpg_UX1000.jpg" alt="Us Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Us</h5>
                        <p class="entertainment-genre">Genre: Horror</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://mvlteenvoice.com/wp-content/uploads/2021/09/p_cruella_21672_ba40c762.jpeg" alt="Cruella Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Cruella</h5>
                        <p class="entertainment-genre">Genre: Comedy</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BYjU1ZWMxYTUtNzQ1ZC00ZTcxLTg0NTMtMzY1ZmQyZjhmYjMyXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Megan</h5>
                        <p class="entertainment-genre">Genre: Action</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BMWMzYjNiZWMtMDg4NS00MDgyLTk5MWItOTFmNjg4NzRhZmExXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Little Women</h5>
                        <p class="entertainment-genre">Genre: Drama</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BMjUxMDQwNjcyNl5BMl5BanBnXkFtZTgwNzcwMzc0MTI@._V1_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Get Out</h5>
                        <p class="entertainment-genre">Genre: Horror</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="movie">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BODU0ZGM0MjctM2YxYy00OWY1LTk2N2YtNWE4ZWQ2ODQwMTI5XkEyXkFqcGc@._V1_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Panic Room</h5>
                        <p class="entertainment-genre">Genre: Suspense</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BYzgzNDVjNjgtNzQxZS00N2E2LTkxNjgtNjIzMGZiM2UwYWQ2XkEyXkFqcGc@._V1_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Downton Abbbey</h5>
                        <p class="entertainment-genre">Genre: Drama</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BNTQzNGZjNDEtOTMwYi00MzFjLWE2ZTYtYzYxYzMwMjZkZDc5XkEyXkFqcGc@._V1_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Sherlock</h5>
                        <p class="entertainment-genre">Genre: Mystery</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BNDY2OWMxNzgtZGQ4Ny00ODI3LTk3MTAtYjM4N2U4ZGI3ZGY1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Farzi</h5>
                        <p class="entertainment-genre">Genre: Suspence</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BZjgzY2QyNzItNDhhYi00ZWIwLWFjN2UtZDJkN2MxYWNjMmJjXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg" alt="Another Movie Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Big Bang Theory</h5>
                        <p class="entertainment-genre">Genre: Comedy</p>
                    </div>
                </div>
            </div>

            <!-- TV Shows -->
            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BNDk4MGU4NTItNDMyMC00NjQ0LWFlMWUtYzJlMTM1M2M2ZTU3XkEyXkFqcGc@.V1_FMjpg_UX1000.jpg" alt="Blacklist Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Blacklist</h5>
                        <p class="entertainment-genre">Genre: Drama</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" data-type="tv">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BOTU2YmM5ZjctOGVlMC00YTczLTljM2MtYjhlNGI5YWMyZjFkXkEyXkFqcGc@.V1_FMjpg_UX1000.jpg" alt="Friends Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Friends</h5>
                        <p class="entertainment-genre">Genre: Comedy</p>
                    </div>
                </div>
            </div>

            <!-- Documentaries -->
            <div class="col-md-4 mb-4" data-type="documentary">
                <div class="card entertainment-card">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRsueOPGw4S72qKI5A_oPxOpQlVSH7Y2GGxg&s" alt="Documentary Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Ghislaine Maxwell</h5>
                        <p class="entertainment-genre">Genre: Action</p>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4" data-type="documentary">
                <div class="card entertainment-card">
                    <img src="https://m.media-amazon.com/images/M/MV5BY2I1ZWJmNDUtMzc5OC00YzVmLTliZWItNTczZDQ0YTNiOTZjXkEyXkFqcGc@.V1.jpg" alt="Documentary Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">American Factory</h5>
                        <p class="entertainment-genre">Genre: Drama</p>
                    </div>
                </div>
            </div>

            <!-- Songs -->
            <div class="col-md-4 mb-4" data-type="song">
                <div class="card entertainment-card">
                    <img src="https://i.pinimg.com/736x/cd/6c/8f/cd6c8f834fce26428e62a46d2c27357b.jpg" alt="Song Thumbnail">
                    <div class="card-body">
                        <h5 class="entertainment-title">Paradise</h5>
                        <p class="entertainment-genre">Artist: Trinity</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include '_footer.php'; ?>


    <!-- Bootstrap JS and Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <!-- Custom JS for Filter -->
    <script>
        function filterContent(category) {
            // Get all the entertainment cards
            const cards = document.querySelectorAll('.entertainment-card');
            
            // Loop through each card
            cards.forEach(card => {
                // Get the type of content (movie, tv, documentary, song)
                const cardType = card.parentElement.getAttribute('data-type');
                
                // If the category is 'all', show all content
                // Otherwise, show only the matching category
                if (category === 'all' || category === cardType) {
                    card.parentElement.style.display = 'block';
                } else {
                    card.parentElement.style.display = 'none';
                }
            });
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
