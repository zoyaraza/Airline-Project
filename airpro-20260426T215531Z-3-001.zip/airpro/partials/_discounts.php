<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
        .text-primary {
            color: #902454 !important; /* Override Bootstrap default color */
        }

        .card-title {
            font-size: 1.2em;
            font-weight: bold;
            text-align: center;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .card img {
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            height: 150px;
            object-fit: cover;
        }

        .btn-primary {
            background-color: #000080;
            border-color: #902454;
        }

        .btn-primary:hover {
            background-color: #00008B;
            border-color: #902454;
        }
    </style>
</head>

<body>
<?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}?>
<?php include '_dbconnect.php'; ?>    

    <!-- Main Content -->
    <div class="container mt-4">
        <h1 class="text-primary">Welcome to FAST Airways</h1>
        <p class="lead text-primary">Experience comfort and excellence in air travel with our amazing services and offers.</p>

        <div class="card p-4">
            <h5 class="text-primary">Current Discounts</h5>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Get <span class="text-primary">10% off</span> on all flights to Europe - Use code <strong>EUROPE10</strong></li>
                <li class="list-group-item">Enjoy <span class="text-primary">15% off</span> on group bookings (5 or more people) - Use code <strong>GROUP15</strong></li>
                <li class="list-group-item">Free upgrade to <span class="text-primary">Business Class</span> on select flights - Limited offer</li>
            </ul>
        </div>
    </div>

    <?php include '_footer.php'; ?>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>

</html>
