<?php
// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include database connection and necessary models once
include '_loginmodel.php';
include '_signupModel.php';
include '_adminmodel.php';

?>

<style>
    /* Set the background color of the entire page */
    body {
        background-color: #f4f4fc; /* Background color for the page */
        color: #902454; /* Text color */
    }

    /* Set the background color of the navbar */
    .navbar {
        background-color: #3c2431 !important;
    }

    /* Ensure navbar text is white */
    .navbar-brand, .navbar-nav .nav-link {
        color: white !important; /* Navbar text color changed to white */
    }

    /* Specific rule for 'Home' button text color */
    .navbar-nav .nav-item.active .nav-link {
        color: white !important; /* Home button text color */
    }

    /* Active navbar item color */
    .navbar-nav .nav-item.active .nav-link {
        color: #ffd700 !important;
    }

    /* Ensure navbar toggle icon is visible */
    .navbar-toggler-icon {
        background-color: white;
    }

    /* Additional page-specific styling (if needed) */
    .container {
        max-width: 1200px;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="/db_pro/airpro/">FAST Airways</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="/db_pro/airpro/">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../about.php">About</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Services
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="_discounts.php">Discounts</a>
                    <a class="dropdown-item" href="_checkin.php">Check-In Options</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="_entertainment.php">Entertainment</a>
                    <a class="dropdown-item" href="_loyalty.php">Loyalty</a>
                    <a class="dropdown-item" href="_flightshow.php">Flights</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../_contact.php">Contacts</a>
            </li>
        </ul>

        <div class="row mx-2">
            <?php
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                // User is logged in
                echo '<form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                      </form>
                      <a href="_logout.php" class="btn btn-outline-primary ml-2" data-target="#LogoutModel">Logout</a>';
            } else {
                // User is not logged in
                echo '<form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
                      </form>
                      <button class="btn btn-outline-light ml-2" style="border: none;" data-toggle="modal" data-target="#LoginModel">Login</button>
                      <button class="btn btn-outline-light mx-2" style="border: none;" data-toggle="modal" data-target="#signupModel">SignUp</button>';
            }
            ?>
        </div>
    </div>
</nav>

<?php
// Handle success/error messages after signup or login attempt
if (isset($_GET['signupsuccess'])) {
    if ($_GET['signupsuccess'] == "true") {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>SignUp Success!</strong> Your account has been created.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    } else {
        if (isset($_GET['error'])) {
            $error = urldecode($_GET['error']);
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Error!</strong> ' . $error . '
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                  </div>';
        }
    }
}

// Display login messages
if (isset($_GET['login'])) {
    if ($_GET['login'] == 'success') {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Login Successful!</strong> You are now logged in.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    } elseif ($_GET['login'] == 'error') {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> Invalid email or password.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
}
}
?>
