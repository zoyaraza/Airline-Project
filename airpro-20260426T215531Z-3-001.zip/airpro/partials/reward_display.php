<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">

    <title>Rewards and Loyalty Upgrades</title>
   
    <style>
        body {
            background-color: #902454;
            font-family: 'Arial', sans-serif;
        }
        .card-title {
        font-size: 1.2em;
        font-weight: bold;
        color: #000000;
        text-align: center;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .card img {
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        height: 150px;
        object-fit: cover;
    }
    
        .btn-redeem {
            background-color: #902454;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-redeem:disabled {
            background-color: #902454;
            color: #FFFFFF;
            cursor: not-allowed;
        }
        .btn-redeem:hover {
            background-color: #0056b3;
        }
        h3 {
            color: #343a40;
            margin-bottom: 30px;
        }
        .text-uppercase {
            letter-spacing: 1px;
        }
        .text-center {
            text-align: center;
        }
        .container {
            max-width: 2000x; /* Limits the container width for larger images */
        }
        .btn-primary {
        background-color: #902454;
        border-color: #902454;
    }

    .btn-primary:hover {
        background-color: #7c1f40; /* Slightly lighter shade for hover effect */
        border-color: #7c1f40;
    }
    </style>
</head>

<body>

<?php

include('_dbconnect.php');
$user_id = $_SESSION['user_id'];
$loyalty_type = 'none';  // Default value if no loyalty type found

// Check if user_id is set
if (isset($user_id)) {
    // Query to retrieve loyalty_type from the database based on user_id
    $query = "SELECT loyalty_type FROM user WHERE user_id = ?";
    
    // Prepare the query to avoid SQL injection
    if ($stmt = mysqli_prepare($conn, $query)) {
        mysqli_stmt_bind_param($stmt, 'i', $user_id);  // 'i' is for integer
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $loyalty_type);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    }
}

// Reward options
$rewards = [
    ['reward' => 'Mini Perfume Bottle', 'points' => 70, 'description' => 'A travel-size perfume from a popular brand', 'image' => 'https://images.unsplash.com/photo-1458538977777-0549b2370168?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cGVyZnVtZXxlbnwwfHwwfHx8MA%3D%3D'],
    ['reward' => 'SmartWatch', 'points' => 80, 'description' => 'A basic fitness tracker or smartwatch to help passengers stay connected.', 'image' => 'https://images.pexels.com/photos/1682821/pexels-photo-1682821.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    ['reward' => 'Headphones', 'points' => 90, 'description' => 'Good quality earphones for you.', 'image' => 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    ['reward' => 'Bluetooth Speaker', 'points' => 50, 'description' => 'Compact, portable speaker for music on the go.', 'image' => 'https://images.pexels.com/photos/1279365/pexels-photo-1279365.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'],
    ['reward' => 'Kids Lego Box', 'points' => 65, 'description' => 'Large Creative kids lego box.', 'image' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/LEGO_logo.svg/1200px-LEGO_logo.svg.png'],
    ['reward' => 'Scented Candles', 'points' => 50, 'description' => 'Small candles with popular scents like lavender, vanilla or citrus.', 'image' => 'https://www.colishco.com/cdn/shop/files/LILLY.png?v=1719908086'],
    ['reward' => 'Diffusers', 'points' => 75, 'description' => 'Home fragrance diffusers with essential oils.', 'image' => 'https://cdn.lifestylepackaging.com/wp-content/uploads/volant-AuhPy2NofM0-unsplash-1024x683.jpg'],
    ['reward' => 'Bath and Body Set', 'points' => 170, 'description' => 'Sets including shower gel, lotion, and body scrub.', 'image' => 'https://nikkihillapothecary.com/wp-content/uploads/2020/11/Candle-and-bath-gift-set-scaled.jpg'],
    ['reward' => 'Chocolate Box', 'points' => 140, 'description' => 'Experience High-quality chocolates.', 'image' => 'https://www.lechocola.ae/cdn/shop/files/DSC00805_dce7410d-329b-49e6-a4e3-4e797bcba396_1200x1200.jpg?v=1713173787']

];

// Display rewards in card format
echo '<h3 class="my-4 text-center">Available Rewards:</h3>';
echo '<div class="row">';

// Loop through rewards to display them
foreach ($rewards as $reward) {
    echo '<div class="col-md-4 my-3">'; 
    echo '<div class="card" style="width: 100%;">';
    echo '<img src="' . $reward['image'] . '" class="card-img-top" style="height: 250px; object-fit: cover;" alt="' . $reward['reward'] . '">';
    echo '<div class="card-body">';
    echo '<h5 class="card-title">' . $reward['reward'] . '</h5>';
    echo '<p class="card-text">' . $reward['description'] . '</p>';
    echo '<p class="points">Points Required: ' . $reward['points'] . '</p>';

    if ($loyalty_points >= $reward['points']) {
        echo '<form method="POST" action="redeem_reward.php">
            <input type="hidden" name="reward" value="' . $reward['reward'] . '">
            <input type="hidden" name="points" value="' . $reward['points'] . '">
            <input type="submit" class="btn-redeem" value="Redeem">
        </form>';
    } else {
        echo '<button class="btn-redeem" disabled>Not enough points</button>';
    }

    echo '</div>';
    echo '</div>';
    echo '</div>';
}

// Display special rewards for Gold or Platinum loyalty members
if ($loyalty_type == 'Gold' || $loyalty_type == 'Platinum') {
    $lounge = [
        ['lounge' => 'Silver Lounge Access', 'points' => 200, 'description' => 'Access to Silver Lounge for a luxurious experience.', 'image' => 'https://images.travelandleisureasia.com/wp-content/uploads/sites/3/2023/06/07170228/Airport-lounge-4-1600x900.jpg'],
        ['lounge' => 'Gold Lounge Access', 'points' => 250, 'description' => 'Access to Gold Lounge  for a luxurious experience.', 'image' => 'https://c.ekstatic.net/ecl/airport/lounges/table-setting-at-emirates-business-lounge-w1280x960.jpg'],
        ['lounge' => 'Platinum Lounge Access', 'points' => 300, 'description' => 'Access to Platinum Lounge for a luxurious experience.', 'image' => 'https://www.qatarairways.com/content/dam/images/renditions/horizontal-2/brand/lounges/silver-lounge/h2-silver-lounge.jpg']

    ];
    
    // Display special loyalty upgrades in the same card format as rewards
    echo '<h3 class="my-5 text-center text-uppercase font-weight-bold">Special Lounge Access</h3>';
    echo '<div class="row">';

    // Loop through the upgrades array
    foreach ($lounge as $lounge) {
        echo '<div class="col-md-4 mb-4">';
        echo '<div class="card shadow-sm border-0">';
        echo '<img class="card-img-top" src="' . $lounge['image'] . '" alt="' . $lounge['lounge'] . '" style="height: 200px; object-fit: cover;">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title text-center">' . $lounge['lounge'] . '</h5>';
        echo '<p class="card-text text-center">' . $lounge['description'] . '</p>';
        echo '<p class="text-center"><strong>Points Required: ' . $lounge['points'] . '</strong></p>';
        
        if ($loyalty_points >= $lounge['points']) {
            echo '<div class="d-flex justify-content-center">';
            echo '<form method="POST" action="reedem_lounge.php">
                    <input type="hidden" name="lounge" value="' . $lounge['lounge'] . '">
                    <input type="hidden" name="points" value="' . $lounge['points'] . '">
                    <input type="submit" class="btn btn-primary" value="Redeem">
                  </form>';
            echo '</div>';
        } else {
            echo '<button class="btn btn-secondary d-block mx-auto" disabled>Not enough points</button>';
        }
        
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    echo '</div>';
}

// Display special rewards for Gold or Platinum loyalty members
if ( $loyalty_type == 'Platinum') {
    $upgrades = [
        ['upgrade' => 'Business Class Upgrade', 'points' => 450, 'description' => 'Upgrade to Business Class for a luxurious experience.', 'image' => 'https://media.cntraveler.com/photos/661d5d461583bcd2283398ac/master/w_1600%2Cc_limit/Emirates_dsc-6538-363198.jpg'],
        ['upgrade' => 'First Class Upgrade', 'points' => 600, 'description' => 'Upgrade to First Class for a top-tier experience.', 'image' => 'https://skift.com/wp-content/uploads/2023/06/dsc-6599-808209.jpg']
    ];
    
    // Display special loyalty upgrades in the same card format as rewards
    echo '<h3 class="my-5 text-center text-uppercase font-weight-bold">Special Class Upgrade</h3>';
    echo '<div class="row">';

    // Loop through the upgrades array
    foreach ($upgrades as $upgrade) {
        echo '<div class="col-md-4 mb-4">';
        echo '<div class="card shadow-sm border-0">';
        echo '<img class="card-img-top" src="' . $upgrade['image'] . '" alt="' . $upgrade['upgrade'] . '" style="height: 200px; object-fit: cover;">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title text-center">' . $upgrade['upgrade'] . '</h5>';
        echo '<p class="card-text text-center">' . $upgrade['description'] . '</p>';
        echo '<p class="text-center"><strong>Points Required: ' . $upgrade['points'] . '</strong></p>';
        
        if ($loyalty_points >= $upgrade['points']) {
            echo '<div class="d-flex justify-content-center">';
            echo '<form method="POST" action="reedem_upgrade.php">
                    <input type="hidden" name="upgrade" value="' . $upgrade['upgrade'] . '">
                    <input type="hidden" name="points" value="' . $upgrade['points'] . '">
                    <input type="submit" class="btn btn-primary" value="Redeem">
                  </form>';
            echo '</div>';
        } else {
            echo '<button class="btn btn-secondary d-block mx-auto" disabled>Not enough points</button>';
        }
        
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    echo '</div>';
}

echo '</div>';
?>


</div>
<!-- Include Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>