<?php
session_start();
// Include the database connection file
include '_dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the complaint and user_id from the form and session
    $complaints = $_POST['complaints']; // The complaint text
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session
    
    // Fetch user email and password from the database based on user_id
    $check_query = "SELECT email, password FROM user WHERE user_id = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_email, $user_password);
    
    if ($stmt->fetch()) {
        // Save the complaint to the user's table
        $update_query = "UPDATE user SET complaints = ? WHERE user_id = ?";
        $stmti = $conn->prepare($update_query);
        $stmti->bind_param("si", $complaints, $user_id);
        
        if ($stmti->execute()) {
            // Redirect with a success message
            header("Location: ../complaint_form.php?success=1");
            exit();
        } else {
            // Redirect with an error message
            header("Location: ../complaint_form.php?error=1");
            exit();
        }

        $stmti->close();
    } else {
        // Redirect with an error message if user is not found
        header("Location: ../complaint_form.php?error=1");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
