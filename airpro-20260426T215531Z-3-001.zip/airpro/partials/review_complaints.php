<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Review Complaints - Admin Panel</title>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #942454;
        }

        .btn-primary {
            background-color: #942454;
            border-color: #942454;
        }

        .btn-primary:hover {
            background-color: #701a3f;
            border-color: #701a3f;
        }

        .table thead th {
            background-color: #942454;
            color: #fff;
        }

        .btn-back {
            background-color: #6c757d;
            border-color: #5a6268;
        }

        .btn-back:hover {
            background-color: #5a6268;
            border-color: #4e555b;
        }
    </style>
</head>

<body>
    <?php include '_headeradmininside.php'; ?>

    <div class="container my-5">
        <h2>Review Complaints</h2>

        <?php
        // Check if the user is an admin
        
        // Include database connection
        include '_dbconnect.php';

        // Show success or error messages
        if (isset($_GET['success']) && $_GET['success'] == 1) {
            echo '<div class="alert alert-success">Complaint status updated successfully.</div>';
        } elseif (isset($_GET['error']) && $_GET['error'] == 1) {
            echo '<div class="alert alert-danger">Failed to update the complaint status. Please try again.</div>';
        }

        // Fetch all complaints
        $query = "SELECT user_id, complaints, complaint_status FROM user WHERE complaints IS NOT NULL";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            echo '<table class="table table-bordered">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>User ID</th>';
            echo '<th>Complaint</th>';
            echo '<th>Status</th>';
            echo '<th>Action</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
            
            while ($row = $result->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . $row['user_id'] . '</td>';
                echo '<td>' . htmlspecialchars($row['complaints']) . '</td>';
                echo '<td>' . htmlspecialchars($row['complaint_status']) . '</td>';
                echo '<td>
                        <form action="_update_complaint_status.php" method="post" class="form-inline">
                            <input type="hidden" name="user_id" value="' . $row['user_id'] . '">
                            <select name="complaint_status" class="form-control mr-2">
                                <option value="Pending"' . ($row['complaint_status'] == 'Pending' ? ' selected' : '') . '>Pending</option>
                                <option value="Resolved"' . ($row['complaint_status'] == 'Resolved' ? ' selected' : '') . '>Resolved</option>
                                <option value="Rejected"' . ($row['complaint_status'] == 'Rejected' ? ' selected' : '') . '>Rejected</option>
                            </select>
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                      </td>';
                echo '</tr>';
            }

            echo '</tbody>';
            echo '</table>';
        } else {
            echo '<div class="alert alert-info">No complaints found.</div>';
        }
        ?>

<div class="mt-4 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include '_dbconnect.php';

    $user_id = $_POST['user_id'];
    $complaint_status = $_POST['complaint_status'];

    // Update complaint status in the database
    $query = "UPDATE user SET complaint_status = ? WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $complaint_status, $user_id);

    if ($stmt->execute()) {
        // Redirect back with success message
        header("Location: ../review_complaints.php?success=1");
    } else {
        // Redirect back with error message
        header("Location: ../review_complaints.php?error=1");
    }

    $stmt->close();
    $conn->close();
}
?>
