<?php
// Start the session and include the database connection
session_start();
include '_dbconnect.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $booking_id = $_POST['booking_id'];
    $payment_method = $_POST['payment_method'];
    $card_number = $_POST['card_number'];
    $expiration_date = $_POST['expiration_date'];
    $cvv = $_POST['cvv'];

    // Validate input data (basic validation)
    if (empty($booking_id) || empty($payment_method) || empty($card_number) || empty($expiration_date) || empty($cvv)) {
        header("Location: payment.php?error=All fields are required.");
        exit;
    }

    // Fetch the total price for the booking
    $sql_booking = "SELECT total_price FROM booking WHERE booking_id = '$booking_id'";
    $result_booking = mysqli_query($conn, $sql_booking);

    if ($result_booking && mysqli_num_rows($result_booking) > 0) {
        $row_booking = mysqli_fetch_assoc($result_booking);
        $amount = $row_booking['total_price'];

        // Insert payment details into the Payment table
        $sql_payment = "INSERT INTO payment (booking_id, amount, payment_method, status) 
                        VALUES ('$booking_id', '$amount', '$payment_method', 'Successful')";

        if (mysqli_query($conn, $sql_payment)) {
            // Payment processed successfully
            header("Location: payment.php?success=1");
            exit;
        } else {
            // Database error
            header("Location: payment.php?error=Failed to process payment. Please try again.");
            exit;
        }
    } else {
        // Booking not found
        header("Location: payment.php?error=Invalid booking ID.");
        exit;
    }
} else {
    // Invalid request method
    header("Location: payment.php?error=Invalid request.");
    exit;
}
?>
