<?php
session_start();
include '_dbconnect.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Email function to send the confirmation email
function sendEmail($email, $subject, $body) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'airlineproject18@gmail.com';
        $mail->Password   = 'vhtf imfw viop zgkg'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('airlineproject18@gmail.com', 'Airline Rewards');
        $mail->addAddress($email);

        // Email content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        // Send email
        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        return false; // Failed to send email
    }
}

if (isset($_POST['reward'], $_POST['points_required'], $_POST['remaining_points'], $_POST['email'])) {
    $reward = $_POST['reward'];
    $points_required = (int)$_POST['points_required'];
    $remaining_points = (int)$_POST['remaining_points'];
    $email = $_POST['email'];
    $user_id = $_SESSION['user_id'];

    // Update the loyalty points in the database
    $sql = "UPDATE user SET loyalty_points = ? WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $remaining_points, $user_id);

    if ($stmt->execute()) {
        // Update the session with the new loyalty points
        $_SESSION['loyalty_points'] = $remaining_points;  // Refresh session loyalty points

        // Generate voucher code
        $voucher_code = strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 10)); // Example voucher code
        $redeem_date = date('Y-m-d H:i:s'); // Current date and time

        // Prepare email content
        $subject = "Your Reward Redemption Confirmation";
        $body = "Hello,<br><br>
                 You have successfully redeemed the following reward:<br><br>
                 <strong>Reward:</strong> $reward<br>
                 <strong>Voucher Code:</strong> $voucher_code<br>
                 <strong>Redeem Date:</strong> $redeem_date<br>
                 <strong>Remaining Loyalty Points:</strong> $remaining_points<br><br>
                 Thank you for being a loyal customer!<br><br>
                 Regards,<br>Airline Team";

        // Send email
        $email_sent = sendEmail($email, $subject, $body);

        if ($email_sent) {
            // Set session message for success
            $_SESSION['redeem_success'] = "Reward redeemed successfully! A voucher has been sent to your email.";
        } else {
            // Set session message for warning if email fails
            $_SESSION['redeem_success'] = "Reward redeemed, but the email could not be sent.";
        }

        // Redirect back to loyalty page (or any relevant page)
        header("Location: silver_loyalty.php");
        exit();
    } else {
        echo "<div class='alert alert-danger'>Error updating loyalty points in the database.</div>";
    }
} else {
    echo "<div class='alert alert-danger'>Invalid request or session expired.</div>";
}
?>
