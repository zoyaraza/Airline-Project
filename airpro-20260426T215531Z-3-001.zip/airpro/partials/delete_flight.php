<?php
session_start();

// Include database connection
include '_dbconnect.php';

// Check if admin is logged in
// if (!isset($_SESSION['adminlogin']) || $_SESSION['adminlogin'] !== true) {
//     header("Location: index.php");
//     exit();
// }

// Check if a flight id is passed to delete
if (isset($_GET['flight_id'])) {
    $flight_id = $_GET['flight_id'];

    // Delete flight from the database
    $sql = "DELETE FROM Flight WHERE flight_id = '$flight_id'";

    if (mysqli_query($conn, $sql)) {
        $success = "Flight deleted successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}

// Fetch all flights from the database
$sql = "SELECT * FROM Flight";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Flight</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
    <?php include '_headeradmininside.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Manage Flights</h1>

        <!-- Success/Error Message -->
        <?php if (isset($success)) { ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php } ?>
        <?php if (isset($error)) { ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php } ?>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Departure City</th>
                    <th>Arrival City</th>
                    <th>Departure Date</th>
                    <th>Departure Time</th>
                    <th>Arrival Date</th>
                    <th>Arrival Time</th>
                    <th>Status</th>
                    <th>Available Seats</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['flight_number']; ?></td>
                        <td><?php echo $row['departure_city']; ?></td>
                        <td><?php echo $row['arrival_city']; ?></td>
                        <td><?php echo $row['departure_date']; ?></td>
                        <td><?php echo $row['departure_time']; ?></td>
                        <td><?php echo $row['arrival_date']; ?></td>
                        <td><?php echo $row['arrival_time']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                        <td><?php echo $row['available_seats']; ?></td>
                        <td><?php echo $row['price']; ?></td>
                        <td>
                            <a href="delete_flight.php?flight_id=<?php echo $row['flight_id']; ?>" 
                               class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this flight?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
    <div class="mt-4 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
