<?php
session_start();
include '_dbconnect.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    // Get the submitted loyalty type
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['loyalty_type'])) {
        $loyalty_type = $_POST['loyalty_type'];
        $user_id = $_SESSION['user_id']; // Assume the user's ID is stored in the session
        
        // Update the loyalty_type in the database
        $sql = "UPDATE user SET loyalty_type = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $loyalty_type, $user_id);
        
        if ($stmt->execute()) {
            // Redirect back to the loyalty page with a success message
            header("Location: _loyalty.php?success=1");
            exit();
        } else {
            // If there's an error, display an error message
            echo '<div class="alert alert-danger">There was an error updating your loyalty type. Please try again.</div>';
        }
    }
} else {
    echo '<div class="alert alert-warning">Please log in to join the loyalty program.</div>';
}
?>
