<?php
// Include database connection
include '_dbconnect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['passenger_id'])) {
    $passenger_id = $_POST['passenger_id'];

    // Update check-in status in the passenger table
    $query_checkin = "UPDATE passengers SET checkin_status = 'pending' WHERE passenger_id = ?";
    $stmt_checkin = $conn->prepare($query_checkin);
    $stmt_checkin->bind_param('i', $passenger_id);
    $stmt_checkin->execute();

    // Return success response
    if ($stmt_checkin->affected_rows > 0) {
        echo 'success';
    } else {
        echo 'failure';
    }
}
?>
