<?php
// Include the database connection file
include '_dbconnect.php';

// Check if booking_id is set in the URL
if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];

    // Update the payment status to "Successful"
    $sql = "UPDATE payment SET status = 'Successful' WHERE booking_id = ?";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind the parameter
    $stmt->bind_param("i", $booking_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect to _gentickets.php after successful update
        header("Location: _gentickets.php?booking_id=$booking_id");
        exit();
    } else {
        echo "Error updating payment status: " . $conn->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Error: Booking ID not found.";
}
?>
<!-- 
<?php
require_once("../vendor/autoload.php");
use Dotenv\Dotenv;

// Load environment variables
$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

date_default_timezone_set('Asia/Karachi');

// Fetch the response from JazzCash
$pp_ResponseCode = $_POST['pp_ResponseCode'];
echo "response code :";
echo "<br>$pp_ResponseCode<br>";
$pp_ResponseMessage = $_POST['pp_ResponseMessage'];
echo "pp_ResponseMessage  :";
echo "<br>$pp_ResponseMessage<br>";
$pp_TransactionId = $_POST['pp_TxnRefNo'];
echo "pp_TransactionId  :";
echo "<br>$pp_TransactionId<br>";
$pp_SecureHash = $_POST['pp_SecureHash'];
echo "pp_SecureHash  :";
echo "<br>$pp_SecureHash<br>";
$integritySalt = $_ENV['INTEGRITY_SALT'];
echo "integritySalt  :";
echo "<br>$integritySalt<br>";
// Verify the secure hash
$hashString = $integritySalt . '&' . $_POST['pp_Amount'] . '&' . $_POST['pp_TxnRefNo'];
$calculatedHash = hash_hmac('sha256', $hashString, $integritySalt);
if ($calculatedHash != $pp_SecureHash) {
    die('Error: Hash verification failed. Payment data is tampered.');
}

// Update payment status based on the response code
$status = ($pp_ResponseCode === '000') ? 'Successful' : 'Failed';
// Retrieve the booking ID (this should be securely passed and retrieved)
$booking_id = isset($_SESSION['booking_id']) ? $_SESSION['booking_id'] : null;

if (!$booking_id) {
    die('Error: Booking ID not found.');
}
// Update the payment record in the database
$sql_update_status = "UPDATE payment SET status = ?, transaction_id = ? WHERE booking_id = ?";
$stmt = $conn->prepare($sql_update_status);
$stmt->bind_param('ssi', $status, $pp_TransactionId, $booking_id);

if ($stmt->execute()) {
    if ($status === 'Successful') {
        // Redirect to a success page
        echo <<<HTML
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <title>Payment Successful</title>
        </head>
        <body>
            <h1>Payment Successful</h1>
            <p>Your payment was processed successfully. Thank you for booking with FAST Airways!</p>
            <a href="/db_pro/airpro/">Return to Home</a>
        </body>
        </html>
        HTML;
    }
    else
    {
        // Redirect to a failure page
        echo <<<HTML
        <!doctype html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <title>Payment Failed</title>
        </head>
        <body>
            <h1>Payment Failed</h1>
            <p>Unfortunately, your payment could not be processed. Please try again or contact support.</p>
            <a href="/db_pro/airpro/">Return to Home</a>
        </body>
        </html>
        HTML;

    }
} else {
        echo "Error updating payment status: " . $stmt->error;
}
    $stmt->close();
$conn->close();
exit;
?>  -->