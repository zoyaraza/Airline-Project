<?php
// Include database connection
include '_dbconnect.php';
session_start();

// Check if the form is submitted with booking_id and passenger_id
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['booking_id']) && isset($_POST['passenger_id'])) {
    // Get the submitted booking_id and passenger_id
    $booking_id = $_POST['booking_id'];
    $passenger_id = $_POST['passenger_id'];

    // Update the booking status to 'pending'
    $query_update = "UPDATE booking SET status = 'pending' WHERE booking_id = ?";
    $stmt_update = $conn->prepare($query_update);
    $stmt_update->bind_param('i', $booking_id);
    $stmt_update->execute();

    // Redirect to a success page or display a success message
    header("Location: checkin_confirmation.php?booking_id=$booking_id&status=pending");
    exit;
} else {
    // If the form wasn't submitted correctly, redirect back
    header("Location: checkin_form.php");
    exit;
}
?>
