<?php
session_start();

// Include database connection
include '_dbconnect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Booking</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">


    <style>
        /* Improved Styling */
        /* body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7fa;
            padding-top: 20px;
        } */

        .container {
            margin-top: 30px;
        }

        .card {
            width: 100%; /* Ensure the card takes the full available width */
            max-width: 100%; /* Set max width to 100% */
            margin: 0 auto; /* Center the card */
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .card-header {
            background-color: #343a40;
            color: #fff;
            font-size: 1.6em;
            font-weight: bold;
            padding: 20px;
            text-align: center;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }

        .card-body {
            background-color: #fff;
            padding: 20px; /* Adjust padding for better layout */
            border-bottom-left-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        .form-group label {
            font-size: 1.2em;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #ccc;
            padding: 10px 15px;
            font-size: 1.1em;
        }

        .btn-primary {
            background-color: #007bff;
            border-radius: 8px;
            font-size: 1.1em;
            padding: 12px 20px;
            text-transform: uppercase;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        /* Ensuring the table fits and allows horizontal scroll */
        .table-container {
            overflow-x: auto; /* Allow horizontal scroll if table overflows */
            width: 100%;
            max-width: 100%; /* Ensure the container doesn't exceed the screen width */
        }

        .table {
            margin-top: 20px;
            border-radius: 8px;
            border: none;
            box-shadow: 0 4px 80px rgba(0, 0, 0, 0.1);
            width: 100%; /* Make sure the table takes full width */
        }

        table th, table td {
            padding: 15px; /* Increase padding for better readability */
            text-align: center;
            font-size: 1.1em;
            white-space: nowrap; /* Prevent text wrapping */
        }

        table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }

        table td {
            background-color: #fff;
        }

        .message {
            margin-top: 20px;
            color: #d9534f;
            font-size: 1.2em;
            font-weight: 600;
        }

        .sidebar {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .sidebar h4 {
            font-size: 1.5em;
            color: #007bff;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            color: #007bff;
            text-decoration: none;
            font-size: 1.1em;
        }

        .sidebar ul li a:hover {
            text-decoration: underline;
        }

        .sidebar ul li.active a {
            color: #0056b3;
        }
    </style>
</head>

<body>

<?php

include '_headeradmininside.php';
// Handle the form submission to get flight_id from admin
$flight_id = '';
$passengers = [];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['flight_id'])) {
    $flight_id = $_POST['flight_id'];

    // Fetch all passengers related to the given flight_id
    $sql = "SELECT p.passenger_id, p.first_name, p.last_name, p.phone, p.date_of_birth, p.passport_number, p.nationality, 
                   p.class_type, p.price, p.prebook_meal, p.special_ass
            FROM passenger p
            JOIN booking b ON p.booking_id = b.booking_id
            WHERE b.flight_id = ?";

    // Prepare statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $flight_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Store the passengers' data for displaying
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $passengers[] = $row;
        }
    } else {
        $message = "No passengers found for this flight.";
    }
}
?>


</body>
<body>
    <!-- Main content -->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">
                        View Passengers by Flight
                    </div>
                    <div class="card-body">
                        <!-- Flight ID Input Form for Admin -->
                        <form method="POST" action="">
                            <div class="form-group">
                                <label for="flight_id">Enter Flight ID:</label>
                                <input type="text" class="form-control" id="flight_id" name="flight_id" value="<?php echo htmlspecialchars($flight_id); ?>" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Search Passengers</button>
                        </form>

                        <?php if (isset($message)) { echo "<p class='message'>$message</p>"; } ?>

                        <?php if (!empty($passengers)): ?>
                            <h4 class="mt-4 text-center">Passenger List for Flight ID: <?php echo htmlspecialchars($flight_id); ?></h4>
                            <div class="table-container">
                                <table class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Passenger ID</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Phone</th>
                                            <th>Date of Birth</th>
                                            <th>Passport Number</th>
                                            <th>Nationality</th>
                                            <th>Class Type</th>
                                            <th>Price</th>
                                            <th>Pre-booked Meal</th>
                                            <th>Special Assistance</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($passengers as $passenger): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($passenger['passenger_id']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['first_name']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['phone']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['date_of_birth']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['passport_number']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['nationality']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['class_type']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['price']); ?></td>
                                                <td><?php echo htmlspecialchars($passenger['prebook_meal']); ?></td>
                                                <td class="special-assistance"><?php echo htmlspecialchars($passenger['special_ass']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-4 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    <!-- JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy3/xFyoD7lCLQZ6CA6IebV5gDqIuC2fnq6ds1yB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0KryoGoH6Lz2sDhpyhZj1BcF0Lfm34I1JJ7d5uG1bFfq5A0g" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous"></script>


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
