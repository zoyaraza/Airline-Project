<?php
// Include database connection
include '_dbconnect.php';

// Check if the booking_id and status are passed in the URL
if (isset($_GET['booking_id']) && isset($_GET['status'])) {
    $booking_id = $_GET['booking_id'];
    $status = $_GET['status'];

    echo "<h1>Check-In Confirmation</h1>";
    echo "<p>Your booking (ID: $booking_id) has been successfully checked in with status: $status.</p>";
} else {
    echo "<p>Invalid request.</p>";
}
?>
