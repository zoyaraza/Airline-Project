<?php

include '_dbconnect.php';

$booking_id = $_GET['booking_id'];
$verification_code = $_GET['verification_code'];

// Step 1: Query to check the verification code for the booking ID
$sql = "SELECT verification_code, flight_id FROM ticket WHERE booking_id = ? AND verification_code = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $booking_id, $verification_code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Code verified successfully
    // Get the number of passengers for the given booking ID
    $passenger_count_sql = "SELECT COUNT(*) as passenger_count FROM passenger WHERE booking_id = ?";
    $passenger_stmt = $conn->prepare($passenger_count_sql);
    $passenger_stmt->bind_param("i", $booking_id);
    $passenger_stmt->execute();
    $passenger_result = $passenger_stmt->get_result();
    $passenger_row = $passenger_result->fetch_assoc();
    $passenger_count = $passenger_row['passenger_count'];
    
    // Get the flight ID associated with the booking
    $flight_id_sql = "SELECT flight_id FROM booking WHERE booking_id = ?";
    $flight_id_stmt = $conn->prepare($flight_id_sql);
    $flight_id_stmt->bind_param("i", $booking_id);
    $flight_id_stmt->execute();
    $flight_id_result = $flight_id_stmt->get_result();
    $flight_row = $flight_id_result->fetch_assoc();
    $flight_id = $flight_row['flight_id'];
    
    // Now update the available seats for the flight
    $update_seats_sql = "UPDATE flight SET available_seats = available_seats - ? WHERE flight_id = ?";
    $update_seats_stmt = $conn->prepare($update_seats_sql);
    $update_seats_stmt->bind_param("ii", $passenger_count, $flight_id);
    
    if ($update_seats_stmt->execute()) {
        // Successfully updated the status and available seats
        // Now update the status in the ticket table to 'Confirmed'
        $update_sql = "UPDATE ticket SET status = 'Confirmed' WHERE booking_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $booking_id);
        
        if ($update_stmt->execute()) {
            // Successfully updated the ticket status
            echo json_encode(['success' => true, 'message' => 'Tickets verified and flight seats updated.']);
        } else {
            // Failed to update the ticket status
            echo json_encode(['success' => false, 'message' => 'Failed to update the ticket status.']);
        }
        
        $update_stmt->close();
    } else {
        // Failed to update the available seats
        echo json_encode(['success' => false, 'message' => 'Failed to update available seats.']);
    }
    
    $update_seats_stmt->close();
    $passenger_stmt->close();
    $flight_id_stmt->close();
   
} else {
    // Invalid code
    echo json_encode(['success' => false, 'message' => 'Invalid verification code.']);
}

$stmt->close();
$conn->close();
?>
