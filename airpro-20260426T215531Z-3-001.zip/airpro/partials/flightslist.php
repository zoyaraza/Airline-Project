<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
        /* Global styles */
        body {
            font-family: 'Arial', sans-serif;
        }

        .jumbotron {
            color: white;
            text-align: center;
            padding: 150px 20px;
            position: relative;
        }

        .jumbotron::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .jumbotron .container {
            position: relative;
            z-index: 2;
        }

        /* Flight Cards */
        .flight-card {
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .flight-card .departure-arrival {
            padding: 15px;
            background: #f8f9fa;
        }

        .flight-card .flight-info {
            text-align: center;
        }

        .flight-card .flight-price {
            padding: 15px;
            background: #fff;
            border-top: 1px solid #ddd;
        }

        .flight-card .flight-price h3 {
            font-weight: bold;
            color: #902454;
        }
        
        /* Modal Design */
        .modal-header {
            background-color: #007bff;
            color: white;
        }

        .modal-body {
            text-align: center;
        }

        .modal-body p {
            font-size: 1.1em;
            margin-bottom: 20px;
        }

        .modal-body button {
            margin: 10px;
            padding: 10px 20px;
            border-radius: 20px;
        }

        /* Buttons */
        .btn-primary {
            background-color: #902454;
            border: none;
        }

        .btn-primary:hover {
            background-color: #7c1f40;
        }

        /* Plane Icon */
        .flight-path img.plane-icon {
            width: 100px; /* Set a smaller width */
            height: auto; /* Maintain the aspect ratio */
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .flight-card .departure-arrival {
                flex-wrap: wrap;
            }

            .flight-card .vertical-line {
                display: none;
            }
        }
    </style>
</head>
<body>
<?php
// Start session
session_start();

// Check if the user is an admin and include the appropriate header
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    include '_headeradmininside.php';
} else {
    include '_headerinside.php';
}
?>

<?php include '_dbconnect.php'; ?>
<?php
// Validate and retrieve city ID from URL
if (isset($_GET['city_id']) && is_numeric($_GET['city_id'])) {
    $city_id = intval($_GET['city_id']);

    // Fetch city details
    $stmt = $conn->prepare("SELECT * FROM city WHERE city_id = ?");
    $stmt->bind_param("i", $city_id);
    $stmt->execute();
    $city_result = $stmt->get_result();
    $stmt->close();

    if ($city_result->num_rows > 0) {
        $city_row = $city_result->fetch_assoc();
        $cityname = htmlspecialchars($city_row['name']);
        $citycountry = htmlspecialchars($city_row['country']);
        $image_url = htmlspecialchars($city_row['image_url']);
    } else {
        echo "<p>City not found!</p>";
        exit;
    }
} else {
    echo "<p>City ID not specified or invalid!</p>";
    exit;
}
?>

<div class="jumbotron" style="background: url('<?php echo $image_url; ?>') no-repeat center center; background-size: cover;">
    <div class="container">
        <h1 class="display-4"><?php echo $cityname; ?> Flights</h1>
        <h2><?php echo $citycountry; ?></h2>
        <hr class="my-4">
    </div>
</div>

<div class="container">
    <div class="row">
        <?php
        // Fetch all flights departing from the selected city
        $stmt = $conn->prepare("SELECT * FROM flight WHERE departure_city = ?");
        $stmt->bind_param("i", $city_id);
        $stmt->execute();
        $flights_result = $stmt->get_result();
        $stmt->close();

        if ($flights_result->num_rows > 0) {
            while ($flight = $flights_result->fetch_assoc()) {
                $arrival_city_id = $flight['arrival_city'];

                // Fetch arrival city name
                $arrival_stmt = $conn->prepare("SELECT name FROM city WHERE city_id = ?");
                $arrival_stmt->bind_param("i", $arrival_city_id);
                $arrival_stmt->execute();
                $arrival_result = $arrival_stmt->get_result();
                $arrival_city_name = ($arrival_result->num_rows > 0) ? htmlspecialchars($arrival_result->fetch_assoc()['name']) : "Unknown City";
                $arrival_stmt->close();

                $departure_date = htmlspecialchars($flight['departure_date']);
                $arrival_date = htmlspecialchars($flight['arrival_date']);
                $departure_time = date("H:i", strtotime($flight['departure_time']));
                $arrival_time = date("H:i", strtotime($flight['arrival_time']));
                $price = htmlspecialchars($flight['price']);
                $total_seats = htmlspecialchars($flight['total_seats']);
                $available_seats = htmlspecialchars($flight['available_seats']);
                $flight_number = htmlspecialchars($flight['flight_number']);
                $flight_id = $flight['flight_id'];

                echo '
                <div class="col-md-12 mb-3">
                    <div class="flight-card">
                        <div class="departure-arrival d-flex justify-content-around">
                            <div class="flight-info">
                                <strong>Departure:</strong><br>
                                ' . $cityname . '<br>
                                <strong>Date:</strong> ' . $departure_date . '<br>
                                <strong>Time:</strong> ' . $departure_time . '
                            </div>
                            <div class="flight-path d-flex align-items-center">
                                <img src="https://www.freeiconspng.com/thumbs/airplane-icon-png/plane-icon-png-images--pictures--becuo-8.png" alt="Plane" class="plane-icon">
                            </div>
                            <div class="flight-info">
                                <strong>Arrival:</strong><br>
                                ' . $arrival_city_name . '<br>
                                <strong>Date:</strong> ' . $arrival_date . '<br>
                                <strong>Time:</strong> ' . $arrival_time . '
                            </div>
                        </div>
                        <div class="flight-price text-center">
                            <h3>$ ' . $price . '</h3>
                            <p>Total Seats: ' . $total_seats . '</p>
                            <p>Available Seats: ' . $available_seats . '</p>';
                
                if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
                    echo '<button class="btn btn-primary" onclick="showLoginModal()">Book Now</button>';
                } else {
                    echo '<a href="/db_pro/airpro/partials/_booking.php?flight_id=' . $flight_id . '" class="btn btn-primary">Book Now</a>';
                }
                
                echo '</div></div></div>';
            }
        } else {
            echo '<div class="col-12 text-center"><p>No flights available from this city.</p></div>';
        }
        ?>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="LoginModel_1" tabindex="-1" role="dialog" aria-labelledby="LoginModelLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="LoginModelLabel">Login or Signup</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">
                <p>Please login or sign up to book flights.</p>
                <button class="btn btn-primary mx-2" style="border: none;" data-toggle="modal" data-target="#LoginModel" data-dismiss="modal">Login</button>
                <button class="btn btn-primary mx-2" style="border: none;" data-toggle="modal" data-target="#signupModel" data-dismiss="modal">SignUp</button>
            </div>
        </div>
    </div>
</div>

<?php include '_footer.php'; ?>
<script>
function showLoginModal() {
    $('#LoginModel_1').modal('show');
}
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">

    </script>