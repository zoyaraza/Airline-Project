<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Check-In Options - FAST Airways</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        /* Flexbox parent row */
        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        /* Ensure all cards are the same height */
        .checkin-option-card {
            display: flex;
            flex-direction: column; /* Align content vertically */
            justify-content: space-between; /* Distribute space evenly */
            align-items: stretch; /* Stretch elements to fit */
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
            height: 100%; /* Consistent height for all cards */
        }

        /* Hover effect */
        .checkin-option-card:hover {
            transform: translateY(-5px);
        }

        /* Image styling for consistent size */
        .checkin-option-card img {
            width: 100%; /* Full width */
            height: 200px; /* Consistent height for images */
            object-fit: cover; /* Maintain aspect ratio and fill space */
            border-radius: 8px;
        }

        .checkin-option-title {
            font-size: 1.5em;
            margin-top: 15px;
            text-align: center;
        }

        .checkin-option-description {
            margin-top: 10px;
            color: #555;
            flex-grow: 1; /* Expand to fill space between elements */
            text-align: center;
        }

        .checkin-option-btn {
            margin-top: 20px;
            font-size: 1em;
            padding: 12px 25px;
            align-self: center; /* Center-align button */
        }
    </style>
</head>
<body>

<?php // Check if the user is logged in and whether they are an admin
       session_start();

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}?><?php include '_dbconnect.php'; ?>

<!-- Main Content -->
<div class="container mt-4">
    <h1 class="text-center mb-4">Choose Your Check-in Option</h1>
    <p class="lead text-center">Select the most convenient method to check-in for your flight and enjoy a seamless journey!</p>

    <!-- Check-in Methods -->
    <div class="row">
        <!-- Online Check-in Card -->
        <div class="col-md-4 d-flex mb-4">
            <div class="checkin-option-card">
                <img src="https://st3.depositphotos.com/1888161/12805/i/950/depositphotos_128054964-stock-photo-two-people-working-on-laptop.jpg" alt="Online Check-in">
                <h3 class="checkin-option-title">Check-in</h3>
                <p class="checkin-option-description">Check in online from the comfort of your home or office. Get your boarding pass instantly and skip the queues.</p>
                <a href="_checkin_form.php" class="btn btn-primary checkin-option-btn"style="border-radius: 50px; font-size: 16px; padding: 15px 30px; background-color: #902454; border-color: #902454;">Start Online Check-in</a>
            </div>
        </div>

        <!-- Mobile App Check-in Card -->
        <div class="col-md-4 d-flex mb-4">
            <div class="checkin-option-card">
                <img src="https://www.qatarairways.com/content/dam/images/mobile/miscellaneous/mobile-app/m-mobile-check-in.jpg" alt="Mobile App Check-in">
                <h3 class="checkin-option-title">Mobile App Check-in</h3>
                <p class="checkin-option-description">Use the FAST Airways mobile app to check-in and receive your boarding pass directly on your phone.</p>
                <a href="_app.php" class="btn btn-primary checkin-option-btn"style="border-radius: 50px; font-size: 16px; padding: 15px 30px; background-color: #902454; border-color: #902454;">Download The App</a>
            </div>
        </div>
        <!-- Airport Kiosk Check-in Card -->
        <div class="col-md-4 d-flex mb-4">
            <div class="checkin-option-card">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNzm0a68SGEngPOw2zRzc9a9asWLFI_lYkRQ&s" alt="Airport Kiosk Check-in">
                <h3 class="checkin-option-title">Airport Kiosk Check-in</h3>
                <p class="checkin-option-description">For a quick and easy check-in, use the self-service kiosks at the airport.</p>
                <a href="kiosk_checkin.php" class="btn btn-primary checkin-option-btn"style="border-radius: 50px; font-size: 16px; padding: 15px 30px; background-color: #902454; border-color: #902454;">Find a Kiosk</a>
            </div>
        </div>
    </div>

    <!-- Additional Information Section -->
    <div class="row mt-5">
        <div class="col-12">
            <h2 class="text-center">Need Assistance?</h2>
            <p class="text-center">If you face any issues during check-in or need help, feel free to contact our support team or visit the airport helpdesk.</p>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
<?php include '_footer.php'; ?>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
