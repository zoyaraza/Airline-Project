<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .container {
            margin: 40px auto;
            max-width: 900px;
        }

        .tiers {
            text-align: center;
            margin-bottom: 30px;
        }

        .tiers .tier {
            display: inline-block;
            margin: 0 15px;
            text-align: center;
        }

        .tiers img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .tiers p {
            font-weight: bold;
            font-size: 1rem;
        }

        .benefits-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .benefits-table th {
            background-color: #442c34;
            color: #fff;
            padding: 15px;
            font-size: 1rem;
        }

        .benefits-table td {
            text-align: center;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .benefits-table tr:nth-child(odd) {
            background-color: #f9f9f9;
        }

        .check-icon {
            color: #28a745;
            font-size: 1.5rem;
        }

        .info-icon {
            color: #6c757d;
            font-size: 1rem;
            cursor: pointer;
        }

        .join-now {
            text-align: center;
            margin: 40px auto;
            background-color: #f4f4fc;
            color: #000;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .join-now h2 {
            font-size: 2rem;
            margin-bottom: 15px;
        }

        .join-now p {
            font-size: 1.2rem;
            margin-bottom: 20px;
        }

        .join-now button {
            background-color: #ffc107;
            border: none;
            color: #000;
            font-size: 1.2rem;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .join-now button:hover {
            background-color: #e0a800;
        }

        .modal-content {
            background-color: #fff;
            border-radius: 8px;
            padding: 30px;
        }

        .modal-header {
            border-bottom: 2px solid #007bff;
        }

        .modal-title {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .modal-body input {
            margin-bottom: 10px;
        }

        .modal-footer {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<?php
session_start();

// Ensure no output is sent before this point
ob_start(); // Start output buffering to prevent header issues

if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}

include '_dbconnect.php';

// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Check if the user has a loyalty_type set (if it's NULL, they haven't joined the loyalty program)
    $sql = "SELECT loyalty_type FROM user WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($loyalty_type);
    $stmt->fetch();
    $stmt->close();

    
    if (!empty($loyalty_type)) {
        // User is logged in and has a loyalty type

        if ($loyalty_type === 'Silver') {
            // Fetch current loyalty points from the user table
            $sql = "SELECT loyalty_points FROM user WHERE user_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($current_loyalty_points);
            $stmt->fetch();
            $stmt->close();
            $_SESSION['loyalty_type'] = $loyalty_type;

            // Initialize loyalty points with the current value from the database
            $loyalty_points = $current_loyalty_points;
    
            // Fetch all bookings that have not yet been redeemed for points
            $sql = "SELECT booking_id FROM booking WHERE user_id = ? AND points_redeemed = FALSE";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->bind_result($booking_id);
    
            // Loop through the bookings and add 15 points for each one
            while ($stmt->fetch()) {
                $loyalty_points += 15; // Add 15 points for each booking
                
                // Mark this booking as redeemed
                $update_booking_sql = "UPDATE booking SET points_redeemed = TRUE WHERE booking_id = ?";
                $update_stmt = $conn->prepare($update_booking_sql);
                $update_stmt->bind_param("i", $booking_id);
                $update_stmt->execute();
                $update_stmt->close();
            }
    
            $stmt->close();

            // Update the user's loyalty points
            $update_points_sql = "UPDATE user SET loyalty_points = ? WHERE user_id = ?";
            $update_points_stmt = $conn->prepare($update_points_sql);
            $update_points_stmt->bind_param("ii", $loyalty_points, $user_id);
            $update_points_stmt->execute();
            $update_points_stmt->close();
            
            // Redirect to silver_loyalty.php page with updated loyalty points
            header("Location: silver_loyalty.php?loyalty_points=" . $loyalty_points);
            exit(); 
        }

        if ($loyalty_type === 'Gold') {
            $sql = "SELECT loyalty_points FROM user WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($current_loyalty_points);
$stmt->fetch();
$stmt->close();

// Initialize loyalty points with the current value from the database
$loyalty_points = $current_loyalty_points;

// Fetch all bookings that have not yet been redeemed for points
$sql = "SELECT booking_id FROM booking WHERE user_id = ? AND points_redeemed = FALSE";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result(); // Make sure all rows are fetched before executing further queries

// Loop through the bookings and add 20 points for each one
while ($stmt->fetch()) {
    $loyalty_points += 20; // Add 20 points for each booking
}

// After fetching, mark all bookings as redeemed in one batch
$update_booking_sql = "UPDATE booking SET points_redeemed = TRUE WHERE user_id = ? AND points_redeemed = FALSE";
$update_stmt = $conn->prepare($update_booking_sql);
$update_stmt->bind_param("i", $user_id);
$update_stmt->execute();
$update_stmt->close();

$stmt->close();

// Update the user's loyalty points
$update_points_sql = "UPDATE user SET loyalty_points = ? WHERE user_id = ?";
$update_points_stmt = $conn->prepare($update_points_sql);
$update_points_stmt->bind_param("ii", $loyalty_points, $user_id);
$update_points_stmt->execute();
$update_points_stmt->close();
header("Location: gold_loyalty.php?loyalty_points=" . $loyalty_points);
exit();

    }
    if($loyalty_type === 'Platinum')
    {
        $sql = "SELECT loyalty_points FROM user WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($current_loyalty_points);
        $stmt->fetch();
        $stmt->close();
        
        // Initialize loyalty points with the current value from the database
        $loyalty_points = $current_loyalty_points;
        
        // Fetch all bookings that have not yet been redeemed for points
        $sql = "SELECT booking_id FROM booking WHERE user_id = ? AND points_redeemed = FALSE";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->store_result(); // Make sure all rows are fetched before executing further queries
        
        // Loop through the bookings and add 20 points for each one
        while ($stmt->fetch()) {
            $loyalty_points += 25; // Add 20 points for each booking
        }
        
        // After fetching, mark all bookings as redeemed in one batch
        $update_booking_sql = "UPDATE booking SET points_redeemed = TRUE WHERE user_id = ? AND points_redeemed = FALSE";
        $update_stmt = $conn->prepare($update_booking_sql);
        $update_stmt->bind_param("i", $user_id);
        $update_stmt->execute();
        $update_stmt->close();
        
        $stmt->close();
        
        // Update the user's loyalty points
        $update_points_sql = "UPDATE user SET loyalty_points = ? WHERE user_id = ?";
        $update_points_stmt = $conn->prepare($update_points_sql);
        $update_points_stmt->bind_param("ii", $loyalty_points, $user_id);
        $update_points_stmt->execute();
        $update_points_stmt->close();
        header("Location: platinum_loyalty.php?loyalty_points=" . $loyalty_points);
        exit();
    }
}

    else {
        echo '
        <!-- Main Container -->
        <div class="container">
            <div class="tiers">
                <div class="tier">
                    <img src="https://honeyland.com.my/wp-content/uploads/2020/03/Silver-Member.jpeg" alt="Silver Tier">
                    <p>Silver</p>
                </div>
                <div class="tier">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmseVM1KNrdi685lwxwCC8r6F4PWQ7YWgneA&s" alt="Gold Tier">
                    <p>Gold</p>
                </div>
                <div class="tier">
                    <img src="https://honeyland.com.my/wp-content/uploads/2020/03/Platinum-Member.jpeg" alt="Platinum Tier">
                    <p>Platinum</p>
                </div>
            </div>

            <!-- Benefits Table -->
            <table class="benefits-table">
                <thead>
                    <tr>
                        <th>Benefits</th>
                        <th>Silver</th>
                        <th>Gold</th>
                        <th>Platinum</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Book rewards with miles</td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                    <tr>
                        <td>Exclusive Lounge Access</td>
                        <td></td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                    <tr>
                        <td>Upgrade flights</td>
                        <td></td>
                        <td></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
        ';
        echo '<div class="join-now">
                <h2>Ready to Join?</h2>
                <p>Sign up today and start enjoying exclusive rewards and benefits!</p>
                <button data-toggle="modal" data-target="#joinModal">Join Now</button>
              </div>';
        }
    }
 else {
    // User is not logged in, show login/signup modal
    echo '
        <!-- Main Container -->
        <div class="container">
            <div class="tiers">
                <div class="tier">
                    <img src="https://honeyland.com.my/wp-content/uploads/2020/03/Silver-Member.jpeg" alt="Silver Tier">
                    <p>Silver</p>
                </div>
                <div class="tier">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmseVM1KNrdi685lwxwCC8r6F4PWQ7YWgneA&s" alt="Gold Tier">
                    <p>Gold</p>
                </div>
                <div class="tier">
                    <img src="https://honeyland.com.my/wp-content/uploads/2020/03/Platinum-Member.jpeg" alt="Platinum Tier">
                    <p>Platinum</p>
                </div>
            </div>

            <!-- Benefits Table -->
            <table class="benefits-table">
                <thead>
                    <tr>
                        <th>Benefits</th>
                        <th>Silver</th>
                        <th>Gold</th>
                        <th>Platinum</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Book rewards with miles</td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                    <tr>
                        <td>Exclusive Lounge Access</td>
                        <td></td>
                        <td><span class="check-icon">✔</span></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                    <tr>
                        <td>Upgrade flights</td>
                        <td></td>
                        <td></td>
                        <td><span class="check-icon">✔</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    ';
    echo '
    <div class="mt-3 text-center">
        <p>To enjoy loyalty rewards, please sign up for the loyalty program!</p>
        <button class="btn btn-primary" data-toggle="modal" data-target="#LoginModel">Login</button>
        <button class="btn btn-secondary ml-2" data-toggle="modal" data-target="#signupModel">Sign Up</button>
    </div>';
}
?>

<!-- Join Now Modal -->
<div class="modal fade" id="joinModal" tabindex="-1" aria-labelledby="joinModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="joinModalLabel">Join the Loyalty Program</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="update_loyalty.php" method="POST">
                    <div class="mb-3">
                        <label for="loyalty_type" class="form-label">Choose Your Loyalty Tier</label><br>
                        <input type="radio" id="silver" name="loyalty_type" value="Silver" required>
                        <label for="silver">Silver</label><br>
                        <input type="radio" id="gold" name="loyalty_type" value="Gold">
                        <label for="gold">Gold</label><br>
                        <input type="radio" id="platinum" name="loyalty_type" value="Platinum">
                        <label for="platinum">Platinum</label><br>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Join Now</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <?php include '_footer.php'; ?>

</body>

</html>
