<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>

    <style>
    .card-title {
        font-size: 1.2em;
        font-weight: bold;
        color: #007bff;
        text-align: center;
    }

    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s;
    }

    .card:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    .card img {
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        height: 150px;
        object-fit: cover;
    }

    .btn-primary {
        background-color: #902454;
        border-color: #902454;
    }

    .btn-primary:hover {
        background-color: #7c1f40; /* Slightly lighter shade for hover effect */
        border-color: #7c1f40;
    }
</style>

</head>

<body>

<?php
// Start the session to track the user's login status
session_start();

// Check if the user is logged in and whether they are an admin
if (isset($_SESSION['user_role']) && $_SESSION['user_role'] == 'admin') {
    // Include the admin header if the user is an admin
    include '_headeradmininside.php';
} else {
    // Include the default header if the user is not an admin
    include '_headerinside.php';
}

// Include database connection
include '_dbconnect.php';
?>

<!-- Card titles starts here -->
<div class="container my-5">
    <h2 class="text-left">Travel The World With Us</h2>
    <div class="row">
        <?php
        // Fetch city data from the database
        $sql = "SELECT * FROM city";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
            $id = $row['city_id'];
            $city_name = $row['name'];
            $country = $row['country'];
            $imageSrc = htmlspecialchars($row['image_url']); // Get high-resolution image URL for the city
            
            echo '
            <div class="col-md-4 my-3">
                <div class="card" style="width: 100%;">
                    <img src="' . $imageSrc . '" class="card-img-top" style="height: 200px; object-fit: cover;" alt="' . $city_name . '">
                    <div class="card-body">
                        <h5 class="card-title"><a href="flightslist.php?city_id=' . $id . '">' . $city_name . ', ' . $country . '</a></h5>
                        <a href="flightslist.php?city_id=' . $id . '" class="btn btn-primary">View Flights</a>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<?php include '_footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
</script>

</body>
</html>
