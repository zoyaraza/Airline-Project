<?php
session_start();

// Include database connection
include '_dbconnect.php';

// Error message variable
$error = "";

// Check if the form is submitted to check if flight_id exists
if (isset($_POST['check_flight'])) {
    $flight_id = $_POST['flight_id'];

    // Check if the flight_id exists in the database
    $sql = "SELECT * FROM Flight WHERE flight_id = '$flight_id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Flight exists, fetch the flight details
        $flight = mysqli_fetch_assoc($result);
    } else {
        // Flight does not exist, show error
        $error = "Flight ID does not exist!";
    }
}

// If the form to update the flight is submitted
if (isset($_POST['update_flight'])) {
    $flight_id = $_POST['flight_id'];
    $flight_number = $_POST['flight_number'];
    $departure_city = $_POST['departure_city'];
    $arrival_city = $_POST['arrival_city'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $status = $_POST['status'];
    $available_seats = $_POST['available_seats'];
    $price = $_POST['price'];

    // Update flight in the database
    $update_sql = "UPDATE Flight SET 
        flight_number = '$flight_number',
        departure_city = '$departure_city',
        arrival_city = '$arrival_city',
        departure_time = '$departure_time',
        arrival_time = '$arrival_time',
        status = '$status',
        available_seats = '$available_seats',
        price = '$price'
        WHERE flight_id = '$flight_id'";

    if (mysqli_query($conn, $update_sql)) {
        $success = "Flight details updated successfully!";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Flight</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" 
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
    <?php include '_headeradmininside.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Modify Flight</h1>

        <!-- Error/Success Message -->
        <?php if ($error) { ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php } ?>
        <?php if (isset($success)) { ?>
            <div class="alert alert-success">
                <?php echo $success; ?>
            </div>
        <?php } ?>

        <!-- Form to enter flight_id -->
        <?php if (!isset($flight)) { ?>
            <form method="POST">
                <div class="form-group">
                    <label for="flight_id">Enter Flight ID to Modify</label>
                    <input type="number" class="form-control" id="flight_id" name="flight_id" required>
                </div>
                <button type="submit" class="btn btn-primary" name="check_flight">Check Flight</button>
            </form>
        <?php } else { ?>
            <!-- Flight details form for editing -->
            <form method="POST">
                <input type="hidden" name="flight_id" value="<?php echo $flight['flight_id']; ?>">
                <div class="form-group">
                    <label for="flight_number">Flight Number</label>
                    <input type="text" class="form-control" id="flight_number" name="flight_number" 
                        value="<?php echo $flight['flight_number']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="departure_city">Departure City</label>
                    <input type="text" class="form-control" id="departure_city" name="departure_city" 
                        value="<?php echo $flight['departure_city']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="arrival_city">Arrival City</label>
                    <input type="text" class="form-control" id="arrival_city" name="arrival_city" 
                        value="<?php echo $flight['arrival_city']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="departure_time">Departure Time</label>
                    <input type="time" class="form-control" id="departure_time" name="departure_time" 
                        value="<?php echo date("H:i", strtotime($flight['departure_time'])); ?>" required>
                </div>
                <div class="form-group">
                    <label for="arrival_time">Arrival Time</label>
                    <input type="time" class="form-control" id="arrival_time" name="arrival_time" 
                        value="<?php echo date("H:i", strtotime($flight['arrival_time'])); ?>" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status">
                        <option value="On-Time" <?php echo ($flight['status'] == 'On-Time') ? 'selected' : ''; ?>>On-Time</option>
                        <option value="Delayed" <?php echo ($flight['status'] == 'Delayed') ? 'selected' : ''; ?>>Delayed</option>
                        <option value="Canceled" <?php echo ($flight['status'] == 'Canceled') ? 'selected' : ''; ?>>Canceled</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="available_seats">Available Seats</label>
                    <input type="number" class="form-control" id="available_seats" name="available_seats" 
                        value="<?php echo $flight['available_seats']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" class="form-control" id="price" name="price" 
                        value="<?php echo $flight['price']; ?>" required>
                </div>

                <button type="submit" class="btn btn-primary" name="update_flight">Update Flight</button>
            </form>
        <?php } ?>
    </div>
    <div class="mt-10 text-center">
            <a href="../_admin.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
