<?php
session_start();
include('_dbconnect.php'); // Ensure this file connects to your database
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title>Travel The World - FAST Airways</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .card {
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-img-top {
            height: 150px; /* Reduced image height */
            object-fit: cover;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        .card-body {
            text-align: center;
            padding: 10px; /* Reduced padding */
        }

        .card-title {
            font-size: 1rem; /* Reduced font size */
            font-weight: bold;
        }

        .card-text {
            font-size: 0.9rem; /* Reduced text size */
            color: #555;
        }

        .points {
            font-size: 1rem;
            color: #ff5722;
            font-weight: bold;
        }

        .btn-redeem {
            background-color: #ffc107;
            color: #000;
            border: none;
            font-weight: bold;
            border-radius: 5px;
            padding: 5px 10px; /* Reduced button size */
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-redeem:hover {
            background-color: #e0a800;
        }
    </style>
</head>

<body>
    <?php include('_headerinside.php'); ?>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row">
            <div class="col-md-12">
                <?php
                // Display success message if available
                if (isset($_SESSION['redeem_success'])) {
                    echo "<div class='alert alert-success'>
                            <p>{$_SESSION['redeem_success']}</p>
                          </div>";
                    unset($_SESSION['redeem_success']); // Remove message after displaying
                }
                if (isset($_SESSION['loyalty_type'])) {
                    $loyalty_type = $_SESSION['loyalty_type'];  // Get loyalty type from session
                } else {
                    $loyalty_type = 'none';  // Default value in case session variable is not set
                }

                if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
                    $user_id = $_SESSION['user_id'];

                    // Fetch the loyalty points of the user
                    $sql = "SELECT loyalty_points FROM user WHERE user_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $stmt->bind_result($loyalty_points);
                    $stmt->fetch();
                    $stmt->close();
                    $_SESSION['loyalty_points'] = $loyalty_points;



                    // Display loyalty points
                    if ($loyalty_points > 0) {
                        echo "<div class='alert alert-success'>
                                <h4>Your Loyalty Points: $loyalty_points</h4>
                              </div>";
                    } else {
                        echo "<div class='alert alert-warning'>
                                <p>You don't have any loyalty points yet.</p>
                              </div>";
                    }
                    include('reward_display.php');
                    }
                else {
                    echo "<div class='alert alert-danger'>
                            <p>You must be logged in to view this page.</p>
                          </div>";
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Footer or Additional content -->
    <?php include('_footer.php'); ?>
</body>

</html>
