<?php
session_start();
ob_start();  // Start output buffering to prevent header issues

include '_dbconnect.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Error: No user session found. Please log in again.");
}

// Fetch flight details
if (isset($_GET['flight_id'])) {
    $flight_id = $_GET['flight_id'];
    $sql = "SELECT flight.*, 
                   dep.name AS departure_city_name, 
                   arr.name AS arrival_city_name 
            FROM flight 
            JOIN city AS dep ON flight.departure_city = dep.city_id 
            JOIN city AS arr ON flight.arrival_city = arr.city_id 
            WHERE flight.flight_id = $flight_id";
    $result = mysqli_query($conn, $sql);
    $flight = mysqli_fetch_assoc($result);
} else {
    echo "<p class='text-center text-danger'>Invalid flight selection.</p>";
    exit();
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seat_count = $_POST['seat_count'];
    $user_id = $_SESSION['user_id'];

    // Insert booking into the database
    $sql_booking = "INSERT INTO booking (user_id, flight_id, status, total_price)
                    VALUES ('$user_id', '$flight_id', 'Pending', 0)"; // Total price will be calculated later
    if (mysqli_query($conn, $sql_booking)) {
        $booking_id = mysqli_insert_id($conn);
        // Redirect to the passenger details page
        header("Location: /db_pro/airpro/partials/_passenger_details.php?flight_id=$flight_id&seat_count=$seat_count&booking_id=$booking_id");
        exit();
    } else {
        echo "<p class='text-center text-danger'>Error creating booking: " . mysqli_error($conn) . "</p>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <title>Book Your Flight - FAST Airways</title>
    <style>
        .form-section {
            margin: 20px 0;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .btn-primary {
            background-color: #902454;
            border: none;
        }

        .btn-primary:hover {
            background-color: #7c1f40; /* Slightly darker shade for hover effect */
        }
    </style>
</head>

<body>
<?php include '_headerinside.php'; ?>
<div class="container my-5">
    <h2 class="text-center mb-4">Book Your Flight</h2>
    <div class="form-section">
        <h5>Flight Details:</h5>
        <p><strong>From:</strong> <?php echo htmlspecialchars($flight['departure_city_name']); ?></p>
        <p><strong>To:</strong> <?php echo htmlspecialchars($flight['arrival_city_name']); ?></p>
        <p><strong>Departure Date:</strong> <?php echo htmlspecialchars($flight['departure_date']); ?></p>
        <p><strong>Arrival Date:</strong> <?php echo htmlspecialchars($flight['arrival_date']); ?></p>
        <p><strong>Departure Time:</strong> <?php echo htmlspecialchars($flight['departure_time']); ?></p>
        <p><strong>Arrival Time:</strong> <?php echo htmlspecialchars($flight['arrival_time']); ?></p>
        <p><strong>Price per seat:</strong> $<?php echo htmlspecialchars($flight['price']); ?></p>
    </div>

        <form action="" method="post">
            <div class="form-group">
                <label for="seat_count">Number of Seats</label>
                <input type="number" class="form-control" id="seat_count" name="seat_count" min="1" max="<?php echo $flight['available_seats']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Proceed to Passenger Details</button>
        </form>
    </div>

    <?php include '_footer.php'; ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>

</html>

