<?php

// Include the database connection file
include '_dbconnect.php';

if (isset($_GET['booking_id'])) {
    $booking_id = $_GET['booking_id'];
} else {
    die("Error: Booking ID not found.");
}

// Step 1: Fetch ticket details based on booking_id
$sql = "SELECT p.first_name, t.seat_number, t.status, t.flight_id FROM ticket t 
        JOIN passenger p ON t.passenger_id = p.passenger_id
        WHERE t.booking_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $passenger_count = $result->num_rows; // Count the number of passengers
    $flight_id = null;

    echo '<div class="container my-4">';
    echo '<h3>Tickets Confirmed</h3>';
    echo '<div class="alert alert-success" role="alert">Your tickets have been successfully verified!</div>';
    echo '<p>Your flight details are as follows:</p>';
    echo '<table class="table table-bordered">';
    echo '<thead><tr><th>Passenger Name</th><th>Seat Number</th><th>Status</th></tr></thead>';
    echo '<tbody>';

    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['first_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['seat_number']) . '</td>';
        echo '<td>' . htmlspecialchars($row['status']) . '</td>';
        echo '</tr>';

        // Fetch the flight_id (assuming all tickets in this booking are for the same flight)
        if (!$flight_id) {
            $flight_id = $row['flight_id'];
        }
    }

    echo '</tbody>';
    echo '</table>';

    // Step 2: Update available_seats for the flight
    if ($flight_id) {
        $update_sql = "UPDATE flight SET available_seats = available_seats - ? WHERE flight_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ii", $passenger_count, $flight_id);

        if ($update_stmt->execute()) {
            echo '<div class="alert alert-info" role="alert">Available seats updated successfully.</div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">Error updating available seats.</div>';
        }

        $update_stmt->close();
    }

    // Step 3: Provide option to proceed to check-in page
    echo '<div class="form-group">';
    echo '<a href="_checkin.php?booking_id=' . $booking_id . '" class="btn btn-primary">Proceed to Check-In</a>';
    echo '</div>';

    echo '</div>'; // Close container
} else {
    echo '<div class="alert alert-danger" role="alert">No ticket details found for this booking.</div>';
}

// Close database connections
$stmt->close();
$conn->close();
?>
