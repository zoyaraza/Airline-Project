<?php
session_start();
include '_dbconnect.php'; // Include your database connection file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login/signup page if not logged in
    header("Location: login.php?message=Please log in or sign up to submit feedback.");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $feedback = trim($_POST['feedback']);
    $user_id = $_SESSION['user_id']; // Get the logged-in user's ID from the session

    if (!empty($feedback)) {
        // Update the feedback column in the user table
        $sql = "UPDATE user SET feedback = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $feedback, $user_id);

        if ($stmt->execute()) {
            // Redirect with success message
            header("Location:../feedback_form.php?success=1");
        } else {
            // Redirect with error message
            header("Location:../feedback_form.php?error=1");
        }
    } else {
        // Redirect if fields are empty
        header("Location:../feedback_form.php?berror=1");
    }
} else {
    // Redirect if accessed without POST
    header("Location:../feedback_form.php");
}
?>
