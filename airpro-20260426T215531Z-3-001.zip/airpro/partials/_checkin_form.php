<?php
// Include the database connection
include '_dbconnect.php';
session_start();

// Initialize variables
$passengers = [];
$booking = null;

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch booking and passenger details when a booking ID is provided
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['booking_id'])) {
    $booking_id = $_POST['booking_id'];

    // Fetch booking details
    $query_booking = "SELECT * FROM booking WHERE booking_id = ?";
    $stmt_booking = $conn->prepare($query_booking);
    $stmt_booking->bind_param('i', $booking_id);
    $stmt_booking->execute();
    $result_booking = $stmt_booking->get_result();

    if ($result_booking->num_rows > 0) {
        $booking = $result_booking->fetch_assoc();

        // Fetch passengers related to this booking
        $query_passengers = "SELECT p.passenger_id, p.first_name, p.last_name, p.checkin_status
                             FROM passenger p
                             JOIN ticket t ON p.passenger_id = t.passenger_id
                             WHERE t.booking_id = ?";
        $stmt_passengers = $conn->prepare($query_passengers);
        $stmt_passengers->bind_param('i', $booking_id);
        $stmt_passengers->execute();
        $passengers_result = $stmt_passengers->get_result();

        while ($passenger = $passengers_result->fetch_assoc()) {
            $passengers[] = $passenger;
        }
    } else {
        $booking = null; // No booking found
    }
}

// Handle status updates (Check-In and Pending)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $passenger_id = $_POST['passenger_id'];
    $new_status = $_POST['status']; // "Pending" or "Checked-In"

    // If the status is "Check-In", first set it to "Pending"
    if ($new_status === 'Pending') {
        $query_update_status = "UPDATE passenger SET checkin_status = 'Pending' WHERE passenger_id = ?";
    } else {
        // For admin to mark it "Checked-In"
        $query_update_status = "UPDATE passenger SET checkin_status = 'Checked-In' WHERE passenger_id = ?";
    }
    $stmt_update_status = $conn->prepare($query_update_status);
    $stmt_update_status->bind_param('i', $passenger_id);

    if ($stmt_update_status->execute()) {
        echo json_encode(['status' => 'success', 'passenger_id' => $passenger_id, 'new_status' => $new_status]);
    } else {
        echo json_encode(['status' => 'error', 'message' => $stmt_update_status->error]);
    }
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <title>Online Check-In</title>
</head>
<body>
    <?php include '_headerinside.php'; ?>

    <div class="container mt-5">
        <h1 class="text-center">Check-In</h1>
        <p class="lead text-center">Enter your booking ID to view passengers.</p>

        <form action="" method="POST">
            <div class="form-group">
                <label for="booking_id">Booking ID</label>
                <input type="text" class="form-control" id="booking_id" name="booking_id" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <?php if ($booking): ?>
            <h3 class="mt-5">Booking Details (Booking ID: <?= htmlspecialchars($booking['booking_id']) ?>)</h3>
            <ul class="list-group mt-3">
                <?php foreach ($passengers as $passenger): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?= htmlspecialchars($passenger['first_name']) ?> <?= htmlspecialchars($passenger['last_name']) ?></strong>
                            <br>
                            <span>Status: <span id="status-<?= $passenger['passenger_id'] ?>"><?= htmlspecialchars($passenger['checkin_status']) ?></span></span>
                        </div>
                        <div>
                            <?php if ($passenger['checkin_status'] === 'Checked-In'): ?>
                                <button class="btn btn-success btn-sm" disabled>Checked-In</button>
                            <?php elseif ($passenger['checkin_status'] === 'Pending'): ?>
                                <button class="btn btn-warning btn-sm" disabled>Pending</button>
                            <?php else: ?>
                                <button class="btn btn-secondary btn-sm status-btn" 
                                        data-passenger-id="<?= $passenger['passenger_id'] ?>" 
                                        data-status="Pending">Check-In</button>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
            <p class="text-danger mt-3">No booking found with the provided ID.</p>
        <?php endif; ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.status-btn').click(function () {
                var passengerId = $(this).data('passenger-id');
                var newStatus = $(this).data('status');

                $.ajax({
                    url: '', // Same page for AJAX
                    type: 'POST',
                    data: {
                        update_status: true,
                        passenger_id: passengerId,
                        status: newStatus
                    },
                    success: function (response) {
                        var data = JSON.parse(response);
                        if (data.status === 'success') {
                            var button = $('.status-btn[data-passenger-id="' + data.passenger_id + '"]');
                            $('#status-' + data.passenger_id).text(data.new_status);

                            if (data.new_status === 'Pending') {
                                button.removeClass('btn-secondary').addClass('btn-warning').text('Pending').prop('disabled', true);
                            } else if (data.new_status === 'Checked-In') {
                                button.removeClass('btn-warning').addClass('btn-success').text('Checked-In').prop('disabled', true);
                            }
                        } else {
                            console.error('Error updating status:', data.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX error:', error);
                    }
                });
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
</body>
</html>
