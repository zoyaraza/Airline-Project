<style>
    /* Set the global background color */
    body {
        background-color: #f4f4fc;
        color: #343a40; /* Text color for contrast */
    }

    /* Uniform styling for links */
    a {
        color: #343a40; /* Darker text color for links */
    }

    a:hover {
        text-decoration: underline; /* Add hover effect */
    }

    /* Footer-specific background and link styles */
    .footer {
        background-color: #f4f4fc; /* Matches body background */
        color: #343a40;
        text-align: center; /* Align text and links in the middle */
    }

    .footer a {
        color: #343a40; /* Matches body text color */
    }

    .footer a:hover {
        text-decoration: underline;
    }

    /* Award images styling */
    .award-img {
        width: 80px; /* Adjust size as needed */
        height: auto; /* Maintain aspect ratio */
        margin: 0 auto; /* Center image horizontally */
    }

    /* Ensure consistent alignment */
    .container-fluid {
        background-color: #f4f4fc; /* Matches body background */
    }

    /* Align content in the middle */
    .row {
        display: flex;
        justify-content: center; /* Align horizontally */
        align-items: center; /* Align vertically */
        flex-wrap: wrap; /* Allow wrapping if needed */
        text-align: center; /* Center text within each section */
    }

    .col-md-2, .col-md-3 {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    /* Style for horizontal lines */
    hr {
        border: 0;
        height: 1px;
        background-color: #ccc;
        margin: 30px 0;
        width: 90%;
    }
</style>
<hr class="my-4">

<div class="row mt-4 footer">
    <div class="row text text-md-start">
        <!-- Section 1: FAST Airways -->
        <div class="col-md-2 mb-3">
            <h6>FAST Airways</h6>
            <ul class="list-unstyled">
                <li><a href="#about" class="text-decoration-none text-dark">About Us</a></li>
                <li><a href="#careers" class="text-decoration-none text-dark">Careers</a></li>
                <li><a href="#press" class="text-decoration-none text-dark">Press Releases</a></li>
                <li><a href="#sustainability" class="text-decoration-none text-dark">Sustainability</a></li>
            </ul>
        </div>
        <!-- Section 2: Our Services -->
        <div class="col-md-2 mb-3">
            <h6>Our Services</h6>
            <ul class="list-unstyled">
                <li><a href="#cargo" class="text-decoration-none text-dark">Cargo Services</a></li>
                <li><a href="#airport" class="text-decoration-none text-dark">Hamad International Airport</a></li>
                <li><a href="#executive" class="text-decoration-none text-dark">Executive Travel</a></li>
                <li><a href="#dutyfree" class="text-decoration-none text-dark">Duty-Free Shopping</a></li>
            </ul>
        </div>
        <!-- Section 3: Business Solutions -->
        <div class="col-md-2 mb-3">
            <h6>Business Solutions</h6>
            <ul class="list-unstyled">
                <li><a href="#corporate" class="text-decoration-none text-dark">Corporate Travel</a></li>
                <li><a href="#events" class="text-decoration-none text-dark">Meetings & Events</a></li>
                <li><a href="#advertise" class="text-decoration-none text-dark">Advertise with Us</a></li>
            </ul>
        </div>
        <!-- Section 4: Business Partners -->
        <div class="col-md-2 mb-3">
            <h6>Business Partners</h6>
            <ul class="list-unstyled">
                <li><a href="#affiliates" class="text-decoration-none text-dark">Affiliate Marketing</a></li>
                <li><a href="#suppliers" class="text-decoration-none text-dark">Supplier Registration</a></li>
            </ul>
        </div>
        <!-- Section 5: Help -->
        <div class="col-md-2 mb-3">
            <h6>Help</h6>
            <ul class="list-unstyled">
                <li><a href="#contact" class="text-decoration-none text-dark">Contact Us</a></li>
                <li><a href="#faq" class="text-decoration-none text-dark">FAQs</a></li>
                <li><a href="#alerts" class="text-decoration-none text-dark">Travel Alerts</a></li>
            </ul>
        </div>
        <!-- Section 6: Social Media -->
        <div class="col-md-2 mb-3">
        <h6>Stay Connected</h6>
            <a href="#" class="text-dark me-2"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="text-dark me-2"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-dark me-2"><i class="fab fa-linkedin-in"></i></a>
            <a href="#" class="text-dark"><i class="fab fa-instagram"></i></a>
        </div>
    </div>


    <!-- Awards Section -->
    <div class="row mt-4 footer">
        <div class="col-md-3">
            <img src="https://www.qatarairways.com/content/dam/images/renditions/square/logos/awards/s-skytrax-2024-aoty-logo.svg" alt="Award 1" class="award-img">
            <p>World's Best Airline 2024</p>
        </div>
        <div class="col-md-3">
            <img src="https://www.qatarairways.com/content/dam/images/renditions/square/logos/awards/s-skytrax-2024-log.svg" alt="Award 2" class="award-img">
            <p>Best Business Class</p>
        </div>
        <div class="col-md-3">
            <img src="https://www.qatarairways.com/content/dam/images/renditions/square/logos/awards/s-skytrax-2024-log.svg" alt="Award 3" class="award-img">
            <p>Best Business Class Lounge</p>
        </div>
        <div class="col-md-3">
            <img src="https://www.qatarairways.com/content/dam/images/renditions/square/logos/awards/s-skytrax-2024-log.svg" alt="Award 4" class="award-img">
            <p>Best Airline in the Middle East</p>
        </div>
    </div>

    <hr class="my-4">

    <!-- Footer Links -->
    <div class="row mt-4 footer">
        <div class="col text-center">
            <ul class="list-inline">
                <li class="list-inline-item"><a href="#cookie" class="text-dark text-decoration-none">Cookie Policy</a></li>
                <li class="list-inline-item"><a href="#privacy" class="text-dark text-decoration-none">Privacy</a></li>
                <li class="list-inline-item"><a href="#accessibility" class="text-dark text-decoration-none">Accessibility</a></li>
                <li class="list-inline-item"><a href="#legal" class="text-dark text-decoration-none">Legal</a></li>
            </ul>
            <p class="mt-2 mb-0">Copyright © FAST Airways 2025 | All Rights Reserved</p>
        </div>
    </div>
</div>
